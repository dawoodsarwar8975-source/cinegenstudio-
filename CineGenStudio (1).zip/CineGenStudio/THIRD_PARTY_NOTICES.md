# Third-party notices

CineGen Studio is a glue application. It does **not** own or relicense the third-party software, fonts, models or voice data listed below. Your use of each component is governed by its upstream license.

## Application runtime

| Component | Used for | License / notes |
|---|---|---|
| [Python](https://www.python.org/) | Runtime | PSF License |
| [Gradio](https://github.com/gradio-app/gradio) | Local web dashboard | Apache-2.0 |
| [Pillow](https://github.com/python-pillow/Pillow) | Image processing | HPND |
| [NumPy](https://github.com/numpy/numpy) | Numeric support | BSD-3-Clause |
| [Requests](https://github.com/psf/requests) | Model downloads and ComfyUI API | Apache-2.0 |
| [psutil](https://github.com/giampaolo/psutil) | Hardware report | BSD-3-Clause |
| [OpenCV](https://github.com/opencv/opencv) | CPU face/mouth detection for lip-sync | Apache-2.0 |
| [arabic-reshaper](https://github.com/mpcabd/python-arabic-reshaper) | Urdu/Arabic subtitle shaping | MIT |
| [python-bidi](https://github.com/MeirKriheli/python-bidi) | Right-to-left subtitle display | LGPL-3.0 |

## Voice synthesis

- [Piper TTS](https://github.com/OHF-Voice/piper1-gpl) is used as an external local engine. The actively maintained engine is **GPL-3.0**.
- Optional voice cloning uses [Chatterbox Multilingual V3](https://github.com/resemble-ai/chatterbox), which is **MIT** licensed. It is installed separately from `requirements-voice-cloning.txt` and downloads its own model weights on first use.
- Voice models come from [rhasspy/piper-voices](https://huggingface.co/rhasspy/piper-voices). **Each voice has its own MODEL_CARD and dataset license.** Some are MIT/CC0/CC-BY, while others are non-commercial. The app exposes a model-card link for every voice. Check it before distributing commercial work.
- No cloud TTS API and no API key are used. Voice files are downloaded once and stored in `models/voices/`.

## Video export

- [imageio-ffmpeg](https://github.com/imageio/imageio-ffmpeg) (BSD-2-Clause) locates or bundles an FFmpeg executable.
- The bundled [FFmpeg](https://ffmpeg.org/) binary's own license depends on the build configuration; static builds commonly include GPL/LGPL components. Review the binary's `-version` output and the upstream build.
- The app uses FFmpeg through command-line subprocess calls.

## Lip-sync cascade

- The CPU lip-sync mode uses OpenCV's bundled `haarcascade_frontalface_default.xml` and a mouth Haar cascade stored at `assets/haarcascade_mcs_mouth.xml`.
- The mouth cascade is mirrored from the [opencv-processing](https://github.com/atduskgreg/opencv-processing/blob/master/lib/cascade-files/haarcascade_mcs_mouth.xml) collection and originates from OpenCV's older `opencv_contrib` face cascades. Review the upstream OpenCV license before redistribution.

## Subtitle fonts

- [Noto Sans](https://github.com/google/fonts/tree/main/ofl/notosans), [Noto Naskh Arabic](https://github.com/google/fonts/tree/main/ofl/notonaskharabic), [Noto Sans Devanagari](https://github.com/google/fonts/tree/main/ofl/notosansdevanagari), and [Noto Sans CJK](https://github.com/notofonts/noto-cjk) are used under the **SIL Open Font License 1.1**. A copy is included at `assets/fonts/OFL-LICENSE.txt`.

## Optional AI Pro engine

- [ComfyUI](https://github.com/Comfy-Org/ComfyUI) is **GPL-3.0**. CineGen Studio talks to a user-installed ComfyUI server through its local HTTP API; it does not distribute or modify ComfyUI source.
- [Wan2.2 TI2V-5B](https://huggingface.co/Wan-AI/Wan2.2-TI2V-5B) weights are **Apache-2.0**. The official ComfyUI guide states that the 5B model should fit on about 8 GB VRAM with native offloading and that Wan2.2 models support commercial use under Apache-2.0.
- The bundled workflow JSON is the official ComfyUI template from [Comfy-Org/workflow_templates](https://github.com/Comfy-Org/workflow_templates/blob/main/templates/video_wan2_2_5B_ti2v.json).
- ComfyUI model files are downloaded from the [Comfy-Org Wan2.2 repackaged repository](https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged) and the [Wan2.1 repackaged text encoder](https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged).

## Generated content

You control the images, scripts and voice prompts you provide. CineGen Studio does not claim ownership of your generated videos or audio. You are responsible for having the necessary rights to character images, music, scripts and any voice data you use.

## No warranty

This is personal-use software provided "as is". It is not legal advice. License terms can change; always verify the upstream license and model card at the time of use.
