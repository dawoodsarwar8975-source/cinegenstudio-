from __future__ import annotations

import re
import textwrap
from pathlib import Path

ARABIC_RANGE = re.compile(r"[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]")
DEVANAGARI_RANGE = re.compile(r"[\u0900-\u097F]")
CJK_RANGE = re.compile(r"[\u3040-\u30FF\u3400-\u4DBF\u4E00-\u9FFF\uAC00-\uD7AF]")

FONT_FILES = {
    "default": ("NotoSans.ttf", "Noto Sans"),
    "arabic": ("NotoNaskhArabic.ttf", "Noto Naskh Arabic"),
    "devanagari": ("NotoSansDevanagari.ttf", "Noto Sans Devanagari"),
    "cjk": ("NotoSansCJKsc.otf", "Noto Sans CJK SC"),
}


def contains_arabic_script(text: str) -> bool:
    return bool(ARABIC_RANGE.search(text))


def font_for_language(language: str, sample_text: str = "") -> tuple[str, str]:
    code = (language or "").lower()
    if code.startswith(("ur", "ar", "fa", "ps", "sd", "ku")) or contains_arabic_script(sample_text):
        return FONT_FILES["arabic"]
    if code.startswith(("hi", "mr", "ne", "sa")) or DEVANAGARI_RANGE.search(sample_text):
        return FONT_FILES["devanagari"]
    if code.startswith(("zh", "ja", "ko")) or CJK_RANGE.search(sample_text):
        return FONT_FILES["cjk"]
    return FONT_FILES["default"]


def _shape_rtl(text: str) -> str:
    try:
        import arabic_reshaper
        from bidi.algorithm import get_display

        return get_display(arabic_reshaper.reshape(text))
    except Exception:
        return text


def _wrap_lines(text: str, max_chars: int, cjk: bool) -> list[str]:
    text = " ".join(text.split())
    if not text:
        return [""]
    if cjk or max_chars < 12:
        return [text[i : i + max_chars] for i in range(0, len(text), max_chars)]
    return textwrap.wrap(
        text,
        width=max_chars,
        break_long_words=False,
        break_on_hyphens=False,
        replace_whitespace=False,
    ) or [text]


def prepare_subtitle_text(text: str, language: str, max_chars: int) -> str:
    cjk = bool(CJK_RANGE.search(text)) or (language or "").lower().startswith(("zh", "ja", "ko"))
    lines = _wrap_lines(text, max_chars, cjk)
    if contains_arabic_script(text):
        lines = [_shape_rtl(line) for line in lines]
    return "\\N".join(_escape_ass(lines_combined) for lines_combined in ["\n".join(lines)])


def _escape_ass(text: str) -> str:
    return (
        text.replace("\\", "\\\\")
        .replace("{", "\\{")
        .replace("}", "\\}")
        .replace("\r\n", "\n")
        .replace("\r", "\n")
        .replace("\n", "\\N")
    )


def format_timestamp(seconds: float, srt: bool = True) -> str:
    seconds = max(0.0, seconds)
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    millis = int(round((seconds - int(seconds)) * 1000))
    if millis == 1000:
        secs += 1
        millis = 0
    if srt:
        return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"
    centis = min(99, millis // 10)
    return f"{hours:d}:{minutes:02d}:{secs:02d}.{centis:02d}"


def write_srt(segments: list[dict], path: Path, language: str = "", max_chars: int = 44) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = []
    for index, segment in enumerate(segments, start=1):
        text = " ".join(str(segment.get("text", "")).split())
        cjk = bool(CJK_RANGE.search(text))
        wrapped = _wrap_lines(text, max_chars, cjk)
        # Keep SRT as editable Unicode. Players such as libass/VLC apply their
        # own bidi shaping; the burned-in ASS file uses pre-shaped text instead.
        lines.append(str(index))
        lines.append(
            f"{format_timestamp(segment['start'])} --> {format_timestamp(segment['end'])}"
        )
        lines.extend(wrapped)
        lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def write_ass(
    segments: list[dict],
    path: Path,
    font_family: str,
    width: int,
    height: int,
    font_size: int | None = None,
) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not font_size:
        font_size = max(20, int(height * 0.032))
    is_cjk = "CJK" in font_family
    max_chars = 22 if is_cjk else (46 if width >= height else 34)
    margin_v = max(36, int(height * 0.075))
    margin_lr = max(40, int(width * 0.07))
    style = (
        "Style: Default,"
        f"{font_family},{font_size},"
        "&H00FFFFFF,&H000000FF,&H00000000,&H80000000,"
        "-1,0,0,0,100,100,0,0,3,2,1,2,"
        f"{margin_lr},{margin_lr},{margin_v},1"
    )
    header = [
        "[Script Info]",
        "ScriptType: v4.00+",
        f"PlayResX: {width}",
        f"PlayResY: {height}",
        "WrapStyle: 2",
        "ScaledBorderAndShadow: yes",
        "YCbCr Matrix: TV.709",
        "",
        "[V4+ Styles]",
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, "
        "Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, "
        "Alignment, MarginL, MarginR, MarginV, Encoding",
        style,
        "",
        "[Events]",
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
    ]
    events = []
    for segment in segments:
        start = format_timestamp(segment["start"], srt=False)
        end = format_timestamp(segment["end"], srt=False)
        text = prepare_subtitle_text(str(segment.get("text", "")), "", max_chars)
        events.append(f"Dialogue: 0,{start},{end},Default,,0,0,0,,{text}")
    path.write_text("\n".join(header + events) + "\n", encoding="utf-8")
    return path


def global_segments(scenes: list[dict]) -> list[dict]:
    result = []
    offset = 0.0
    for scene in scenes:
        for segment in scene.get("subtitle_segments", []):
            result.append(
                {
                    "start": offset + float(segment["start"]),
                    "end": offset + float(segment["end"]),
                    "text": segment["text"],
                }
            )
        offset += float(scene["duration"])
    return result


def escape_filter_value(value: str) -> str:
    value = str(value).replace("\\", "/")
    value = value.replace(":", r"\:")
    value = value.replace("'", r"\'")
    return value


def subtitle_filter(path: Path, fonts_dir: Path, root: Path) -> str:
    try:
        subtitle_path = Path(path).resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        subtitle_path = Path(path).as_posix()
    try:
        font_path = Path(fonts_dir).resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        font_path = Path(fonts_dir).as_posix()
    return (
        f"subtitles=filename='{escape_filter_value(subtitle_path)}'"
        f":fontsdir='{escape_filter_value(font_path)}'"
    )
