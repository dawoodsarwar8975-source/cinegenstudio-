from __future__ import annotations

import json
from pathlib import Path
from typing import Callable

from .config import VOICE_CATALOG_PATH, VOICE_MODEL_DIR
from .downloader import download_file, human_size

HF_BASE = "https://huggingface.co/rhasspy/piper-voices/resolve/main/"

LANGUAGE_NAMES = {
    "ar_JO": "Arabic (Jordan)",
    "bn_BD": "Bengali (Bangladesh)",
    "ca_ES": "Catalan (Spain)",
    "cs_CZ": "Czech (Czechia)",
    "cy_GB": "Welsh (UK)",
    "da_DK": "Danish (Denmark)",
    "de_DE": "German (Germany)",
    "el_GR": "Greek (Greece)",
    "en_GB": "English (UK)",
    "en_US": "English (US)",
    "es_ES": "Spanish (Spain)",
    "es_MX": "Spanish (Mexico)",
    "fa_IR": "Persian (Iran)",
    "fi_FI": "Finnish (Finland)",
    "fr_FR": "French (France)",
    "hi_IN": "Hindi (India)",
    "hu_HU": "Hungarian (Hungary)",
    "is_IS": "Icelandic (Iceland)",
    "it_IT": "Italian (Italy)",
    "ja_JP": "Japanese (Japan)",
    "ka_GE": "Georgian (Georgia)",
    "ko_KR": "Korean (Korea)",
    "lb_LU": "Luxembourgish",
    "ne_NP": "Nepali (Nepal)",
    "nl_NL": "Dutch (Netherlands)",
    "no_NO": "Norwegian (Norway)",
    "pl_PL": "Polish (Poland)",
    "pt_BR": "Portuguese (Brazil)",
    "pt_PT": "Portuguese (Portugal)",
    "ro_RO": "Romanian (Romania)",
    "ru_RU": "Russian (Russia)",
    "sk_SK": "Slovak (Slovakia)",
    "sl_SI": "Slovenian (Slovenia)",
    "sr_RS": "Serbian (Serbia)",
    "sv_SE": "Swedish (Sweden)",
    "sw_CD": "Swahili (Congo)",
    "te_IN": "Telugu (India)",
    "tr_TR": "Turkish (Turkey)",
    "uk_UA": "Ukrainian (Ukraine)",
    "ur_PK": "Urdu (Pakistan)",
    "vi_VN": "Vietnamese (Vietnam)",
    "zh_CN": "Chinese (China)",
}

PREFERRED_LANGUAGES = [
    "en_US",
    "ur_PK",
    "hi_IN",
    "ar_JO",
    "es_ES",
    "fr_FR",
    "de_DE",
    "it_IT",
    "pt_BR",
    "tr_TR",
    "fa_IR",
    "ru_RU",
    "ja_JP",
    "ko_KR",
    "zh_CN",
    "bn_BD",
    "nl_NL",
    "pl_PL",
    "te_IN",
    "vi_VN",
]


def load_catalog() -> dict:
    with VOICE_CATALOG_PATH.open("r", encoding="utf-8") as handle:
        return json.load(handle)


CATALOG = load_catalog()


def language_label(code: str) -> str:
    if code in LANGUAGE_NAMES:
        return LANGUAGE_NAMES[code]
    info = next(
        (v["language"] for v in CATALOG.values() if v["language"].get("code") == code),
        {},
    )
    english = info.get("name_english", code)
    region = info.get("country_english")
    return f"{english} ({region})" if region else english


def available_languages() -> list[str]:
    codes = {v["language"].get("code", "") for v in CATALOG.values()}
    codes = {c for c in codes if c}
    ordered = [c for c in PREFERRED_LANGUAGES if c in codes]
    ordered += sorted(c for c in codes if c not in ordered)
    return ordered


def language_choices() -> list[tuple[str, str]]:
    return [(language_label(code), code) for code in available_languages()]


def recommended_voice(language: str) -> str | None:
    candidates = [k for k, v in CATALOG.items() if v["language"].get("code") == language]
    if not candidates:
        return None
    candidates.sort(
        key=lambda key: (
            0 if CATALOG[key]["quality"] == "medium" else 1,
            voice_size_bytes(key),
            key,
        )
    )
    return candidates[0]


def voice_size_bytes(key: str) -> int:
    info = CATALOG.get(key, {})
    return sum(
        meta.get("size_bytes", 0)
        for path, meta in info.get("files", {}).items()
        if path.endswith(".onnx") or path.endswith(".onnx.json")
    )


def voice_choices(language: str | None = None, only_installed: bool = False) -> list[tuple[str, str]]:
    keys = list(CATALOG.keys())
    if language:
        keys = [k for k in keys if CATALOG[k]["language"].get("code") == language]
    if only_installed:
        keys = [k for k in keys if is_voice_installed(k)]
    keys.sort(key=lambda k: (0 if CATALOG[k]["quality"] == "medium" else 1, voice_size_bytes(k), k))
    choices = []
    for key in keys:
        installed = "✓ " if is_voice_installed(key) else "↓ "
        size = human_size(voice_size_bytes(key)) if voice_size_bytes(key) else "—"
        label = f"{installed}{key} • {CATALOG[key]['quality']} • {size}"
        choices.append((label, key))
    return choices


def voice_model_path(key: str) -> Path:
    info = CATALOG.get(key)
    if not info:
        raise KeyError(f"Unknown Piper voice: {key}")
    onnx_path = next((p for p in info["files"] if p.endswith(".onnx")), None)
    if not onnx_path:
        raise KeyError(f"No ONNX model found for voice: {key}")
    return VOICE_MODEL_DIR / Path(onnx_path).name


def voice_config_path(key: str) -> Path:
    info = CATALOG.get(key)
    if not info:
        raise KeyError(f"Unknown Piper voice: {key}")
    config_path = next((p for p in info["files"] if p.endswith(".onnx.json")), None)
    if not config_path:
        raise KeyError(f"No ONNX config found for voice: {key}")
    return VOICE_MODEL_DIR / Path(config_path).name


def is_voice_installed(key: str) -> bool:
    try:
        model = voice_model_path(key)
        config = voice_config_path(key)
        return model.exists() and model.stat().st_size > 1_000_000 and config.exists()
    except Exception:
        return False


def installed_voices() -> list[str]:
    return [key for key in CATALOG if is_voice_installed(key)]


def model_card_url(key: str) -> str:
    info = CATALOG.get(key, {})
    card = next((p for p in info.get("files", {}) if p.endswith("MODEL_CARD")), "")
    return HF_BASE + card if card else "https://huggingface.co/rhasspy/piper-voices"


def ensure_voice(key: str, progress: Callable[[float, str], None] | None = None) -> tuple[Path, Path]:
    """Download a Piper voice on first use; return local model and config paths."""
    if key not in CATALOG:
        raise KeyError(f"Unknown Piper voice: {key}")
    if is_voice_installed(key):
        return voice_model_path(key), voice_config_path(key)

    progress = progress or (lambda _fraction, _message: None)
    info = CATALOG[key]
    paths = [
        p
        for p in info["files"]
        if p.endswith(".onnx") or p.endswith(".onnx.json") or p.endswith("MODEL_CARD")
    ]
    total = sum(info["files"][p].get("size_bytes", 0) for p in paths)
    done = 0

    for index, repo_path in enumerate(paths, start=1):
        expected = info["files"][repo_path].get("size_bytes") or None
        filename = Path(repo_path).name
        if repo_path.endswith("MODEL_CARD"):
            destination = VOICE_MODEL_DIR / "cards" / f"{key}__{filename}"
        else:
            destination = VOICE_MODEL_DIR / filename
        if destination.exists() and (not expected or destination.stat().st_size == expected):
            done += expected or destination.stat().st_size
            continue
        before = expected or 0

        def local_progress(fraction: float, message: str, _before: int = before) -> None:
            current = done + _before * fraction
            overall = current / total if total else fraction
            progress(overall, f"Voice file {index}/{len(paths)}: {filename} — {message}")

        download_file(
            HF_BASE + repo_path,
            destination,
            progress=local_progress,
            expected_size=expected,
        )
        done += expected or destination.stat().st_size
        progress(done / total if total else 1.0, f"Downloaded {filename}")

    return voice_model_path(key), voice_config_path(key)


def delete_voice(key: str) -> str:
    removed = 0
    for path in (voice_model_path(key), voice_config_path(key)):
        if path.exists():
            path.unlink()
            removed += 1
    card = VOICE_MODEL_DIR / "cards" / f"{key}__MODEL_CARD"
    if card.exists():
        card.unlink()
        removed += 1
    return f"Removed {removed} file(s) for {key}."
