from __future__ import annotations

from pathlib import Path
from typing import Callable

ProgressCallback = Callable[[float, str], None]

# Chatterbox Multilingual V3 language ids. The upstream model supports 23+
# languages; this list covers the most useful ones for CineGen Studio.
VOICE_CLONE_LANGUAGES = sorted(
    {
        "ar", "da", "de", "el", "en", "es", "fa", "fi", "fr", "he",
        "hi", "it", "ja", "ko", "ml", "nl", "no", "pl", "pt", "ru",
        "sv", "sw", "tr", "ur", "zh",
    }
)

LOCALE_TO_CLONE_LANGUAGE = {
    "ar_JO": "ar",
    "bn_BD": "hi",
    "da_DK": "da",
    "de_DE": "de",
    "el_GR": "el",
    "en_GB": "en",
    "en_US": "en",
    "es_ES": "es",
    "es_MX": "es",
    "fa_IR": "fa",
    "fi_FI": "fi",
    "fr_FR": "fr",
    "he_IL": "he",
    "hi_IN": "hi",
    "it_IT": "it",
    "ja_JP": "ja",
    "ko_KR": "ko",
    "ml_IN": "ml",
    "nl_NL": "nl",
    "no_NO": "no",
    "pl_PL": "pl",
    "pt_BR": "pt",
    "pt_PT": "pt",
    "ru_RU": "ru",
    "sv_SE": "sv",
    "sw_CD": "sw",
    "tr_TR": "tr",
    "ur_PK": "ur",
    "zh_CN": "zh",
}

_MODEL_CACHE: dict[str, object] = {}


def locale_to_clone_language(locale: str) -> str:
    locale = (locale or "en_US").lower()
    if locale in LOCALE_TO_CLONE_LANGUAGE:
        return LOCALE_TO_CLONE_LANGUAGE[locale]
    candidate = locale.split("_", 1)[0]
    return candidate if candidate in VOICE_CLONE_LANGUAGES else "en"


def availability() -> dict:
    """Check whether optional Chatterbox voice-cloning dependencies exist."""
    result = {
        "chatterbox": False,
        "torch": False,
        "soundfile": False,
        "device": "cpu",
        "available": False,
        "error": "",
    }
    try:
        import importlib.util

        result["chatterbox"] = importlib.util.find_spec("chatterbox") is not None
        result["soundfile"] = importlib.util.find_spec("soundfile") is not None
        torch_spec = importlib.util.find_spec("torch")
        result["torch"] = torch_spec is not None
        if result["torch"]:
            import torch

            if torch.cuda.is_available():
                result["device"] = "cuda"
            elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                result["device"] = "mps"
            else:
                result["device"] = "cpu"
        result["available"] = bool(result["chatterbox"] and result["torch"] and result["soundfile"])
        if not result["available"]:
            missing = [name for name in ("chatterbox", "torch", "soundfile") if not result[name]]
            result["error"] = "Missing optional packages: " + ", ".join(missing)
    except Exception as exc:
        result["error"] = str(exc)
    return result


def install_instructions() -> str:
    return (
        "python -m pip install -r requirements-voice-cloning.txt\n"
        "# Python 3.11 is recommended for Chatterbox dependencies."
    )


def resolve_device(preferred: str = "auto") -> str:
    preferred = (preferred or "auto").lower()
    try:
        import torch

        if preferred == "cuda" and torch.cuda.is_available():
            return "cuda"
        if preferred == "mps" and hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            return "mps"
        if preferred == "cpu":
            return "cpu"
        if torch.cuda.is_available():
            return "cuda"
        if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            return "mps"
    except Exception:
        pass
    return "cpu"


def get_model(device: str = "cpu", progress: ProgressCallback | None = None):
    """Load and cache the Chatterbox Multilingual V3 model."""
    if device in _MODEL_CACHE:
        return _MODEL_CACHE[device]
    status = availability()
    if not status["available"]:
        raise RuntimeError(
            "Voice cloning is not installed. Run:\n\n"
            + install_instructions()
            + f"\n\nDetails: {status['error']}"
        )
    if progress:
        progress(0.02, "Loading Chatterbox Multilingual V3 (first run downloads ~1–2 GB)…")
    from chatterbox.mtl_tts import ChatterboxMultilingualTTS

    try:
        model = ChatterboxMultilingualTTS.from_pretrained(device=device, t3_model="v3")
    except TypeError:
        # Older chatterbox-tts releases do not expose t3_model.
        model = ChatterboxMultilingualTTS.from_pretrained(device=device)
    _MODEL_CACHE[device] = model
    if progress:
        progress(0.12, "Voice cloning model ready")
    return model


def synthesize_sentence(
    text: str,
    language_id: str,
    reference_audio: Path,
    output_path: Path,
    device: str = "cpu",
    exaggeration: float = 0.5,
    cfg_weight: float = 0.5,
    temperature: float = 0.8,
) -> Path:
    """Generate one sentence in the cloned voice and save 16-bit PCM WAV."""
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    reference_audio = Path(reference_audio)
    if not reference_audio.exists():
        raise FileNotFoundError(f"Reference voice sample not found: {reference_audio}")
    model = get_model(device)
    language_id = (language_id or "en").lower()
    if language_id not in VOICE_CLONE_LANGUAGES:
        language_id = "en"

    kwargs = {
        "language_id": language_id,
        "audio_prompt_path": str(reference_audio),
        "exaggeration": float(exaggeration),
        "cfg_weight": float(cfg_weight),
    }
    try:
        wav = model.generate(text, temperature=float(temperature), **kwargs)
    except TypeError:
        wav = model.generate(text, **kwargs)

    if hasattr(wav, "detach"):
        wav = wav.detach()
    if hasattr(wav, "cpu"):
        wav = wav.cpu()
    if hasattr(wav, "numpy"):
        wav = wav.numpy()
    if hasattr(wav, "squeeze"):
        wav = wav.squeeze()

    import soundfile as sf

    sf.write(str(output_path), wav, model.sr, subtype="PCM_16")
    return output_path
