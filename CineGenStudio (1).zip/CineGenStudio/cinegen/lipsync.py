from __future__ import annotations

import math
import wave
from pathlib import Path
from typing import Callable

import imageio_ffmpeg
import numpy as np
from PIL import Image, ImageDraw, ImageEnhance, ImageFilter

from .config import ASSETS_DIR
from .imaging import compose_scene_frame

ProgressCallback = Callable[[float, str], None]
MOUTH_CASCADE_PATH = ASSETS_DIR / "haarcascade_mcs_mouth.xml"


def audio_envelope(
    wav_path: Path,
    fps: int = 30,
    duration: float | None = None,
    window: float = 0.09,
) -> np.ndarray:
    """Return a smoothed 0..1 loudness envelope for each video frame."""
    wav_path = Path(wav_path)
    with wave.open(str(wav_path), "rb") as handle:
        sample_rate = handle.getframerate()
        channels = handle.getnchannels()
        sample_width = handle.getsampwidth()
        raw = handle.readframes(handle.getnframes())

    if sample_width == 2:
        samples = np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0
    elif sample_width == 1:
        samples = (np.frombuffer(raw, dtype=np.uint8).astype(np.float32) - 128.0) / 128.0
    elif sample_width == 4:
        samples = np.frombuffer(raw, dtype="<i4").astype(np.float32) / 2147483648.0
    else:
        raise RuntimeError(f"Unsupported WAV sample width: {sample_width} bytes")

    if channels > 1 and len(samples) >= channels:
        samples = samples[: len(samples) // channels * channels].reshape(-1, channels).mean(axis=1)
    if len(samples) == 0:
        return np.zeros(max(1, int((duration or 1.0) * fps)), dtype=np.float32)

    if duration is None:
        duration = len(samples) / sample_rate
    frame_count = max(1, int(math.ceil(duration * fps)))
    window_samples = max(1, int(sample_rate * window))
    values = np.zeros(frame_count, dtype=np.float32)
    for index in range(frame_count):
        center = int((index / fps) * sample_rate)
        start = max(0, center - window_samples // 2)
        end = min(len(samples), center + window_samples // 2)
        if end <= start:
            values[index] = 0.0
            continue
        chunk = samples[start:end]
        values[index] = float(np.sqrt(np.mean(chunk * chunk)))

    kernel_size = max(1, int(fps * 0.08))
    if kernel_size > 1:
        kernel = np.ones(kernel_size, dtype=np.float32) / kernel_size
        values = np.convolve(values, kernel, mode="same").astype(np.float32)

    high = float(np.percentile(values, 95))
    if high < 1e-5:
        high = float(values.max()) or 1.0
    values = np.clip(values / high, 0.0, 1.0)
    values = np.power(values, 0.72)
    return values.astype(np.float32)


def _cascade(path: str):
    import cv2

    classifier = cv2.CascadeClassifier(path)
    if classifier.empty():
        raise RuntimeError(f"Could not load Haar cascade: {path}")
    return classifier


def detect_mouth_bbox(image_path: Path) -> tuple[int, int, int, int]:
    """Detect a mouth in the original character image; always return a usable box."""
    import cv2

    image_path = Path(image_path)
    image = cv2.imread(str(image_path))
    if image is None:
        raise RuntimeError(f"Could not read image: {image_path}")
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    height, width = gray.shape

    face_cascade = _cascade(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    faces = face_cascade.detectMultiScale(gray, 1.1, 5, minSize=(80, 80))
    mouth_cascade = _cascade(str(MOUTH_CASCADE_PATH)) if MOUTH_CASCADE_PATH.exists() else None

    if len(faces) > 0:
        x, y, w, h = max(faces, key=lambda rect: rect[2] * rect[3])
        roi_y = y + int(h * 0.42)
        roi = gray[roi_y : y + h, x : x + w]
        if mouth_cascade is not None and roi.size > 0:
            candidates = mouth_cascade.detectMultiScale(
                roi,
                1.2,
                10,
                minSize=(max(20, int(w * 0.14)), max(12, int(h * 0.05))),
                maxSize=(int(w * 0.34), int(h * 0.28)),
            )
            scored = []
            roi_h = max(1, roi.shape[0])
            for mx, my, mw, mh in candidates:
                center_x = mx + mw / 2
                center_y = my + mh / 2
                distance_from_center = abs(center_x - w / 2) / max(1.0, w / 2)
                # The real mouth sits in the lower half of the face ROI;
                # the smaller, higher detection is usually the nose.
                target_y = roi_h * 0.68
                target_w = w * 0.30
                y_penalty = abs(center_y - target_y) / roi_h
                w_penalty = abs(mw - target_w) / max(1.0, w)
                score = 1.0 - min(1.0, 0.35 * distance_from_center + 1.8 * y_penalty + w_penalty)
                scored.append((score, (int(x + mx), int(roi_y + my), int(mw), int(mh))))
            if scored:
                return max(scored, key=lambda item: item[0])[1]
        return (
            int(x + w * 0.30),
            int(y + h * 0.66),
            int(w * 0.40),
            int(h * 0.16),
        )

    if mouth_cascade is not None:
        candidates = mouth_cascade.detectMultiScale(
            gray,
            1.2,
            12,
            minSize=(max(30, int(width * 0.08)), max(18, int(height * 0.04))),
        )
        if len(candidates) > 0:
            x, y, w, h = max(candidates, key=lambda rect: rect[2] * rect[3])
            return int(x), int(y), int(w), int(h)

    return (
        int(width * 0.37),
        int(height * 0.65),
        int(width * 0.26),
        int(height * 0.11),
    )


def _map_bbox_to_frame(
    bbox: tuple[int, int, int, int],
    original_size: tuple[int, int],
    foreground_size: tuple[int, int],
    placement: tuple[int, int],
) -> tuple[int, int, int, int]:
    original_w, original_h = original_size
    fg_w, fg_h = foreground_size
    scale = min(fg_w / original_w, fg_h / original_h)
    x, y, w, h = bbox
    return (
        int(placement[0] + x * scale),
        int(placement[1] + y * scale),
        max(10, int(w * scale)),
        max(8, int(h * scale)),
    )


def _build_mouth_variants(
    base_frame: Image.Image,
    bbox: tuple[int, int, int, int],
    levels: int = 9,
):
    x, y, w, h = bbox
    pad_x = int(w * 0.45)
    pad_y = int(h * 0.75)
    left = max(0, x - pad_x)
    top = max(0, y - pad_y)
    right = min(base_frame.width, x + w + pad_x)
    bottom = min(base_frame.height, y + h + pad_y)
    patch = base_frame.crop((left, top, right, bottom)).convert("RGB")
    patch_w, patch_h = patch.size

    # Feathered mask so the animated mouth patch blends into the face.
    patch_mask = Image.new("L", (patch_w, patch_h), 0)
    mask_draw = ImageDraw.Draw(patch_mask)
    mask_draw.ellipse(
        (
            int(patch_w * 0.08),
            int(patch_h * 0.08),
            int(patch_w * 0.92),
            int(patch_h * 0.92),
        ),
        fill=235,
    )
    patch_mask = patch_mask.filter(ImageFilter.GaussianBlur(max(3, int(min(patch_w, patch_h) * 0.09))))

    variants = []
    patch_rgb = patch.convert("RGB")
    for index in range(levels):
        openness = index / max(1, levels - 1)
        # Darken the original lip pixels instead of painting a foreign color.
        # This preserves the character's skin hue and avoids a bruised look.
        opening_mask = Image.new("L", (patch_w, patch_h), 0)
        draw = ImageDraw.Draw(opening_mask)
        ellipse_w = patch_w * (0.30 + 0.14 * openness)
        ellipse_h = patch_h * (0.03 + 0.18 * openness)
        cx = patch_w / 2
        cy = patch_h * (0.38 + 0.01 * openness)
        draw.ellipse(
            (
                int(cx - ellipse_w / 2),
                int(cy - ellipse_h / 2),
                int(cx + ellipse_w / 2),
                int(cy + ellipse_h / 2),
            ),
            fill=int(150 + 105 * openness),
        )
        opening_mask = opening_mask.filter(
            ImageFilter.GaussianBlur(max(2, int(min(patch_w, patch_h) * 0.02)))
        )
        dark_factor = 1.0 - 0.34 * openness
        dark_patch = ImageEnhance.Brightness(patch_rgb).enhance(dark_factor)
        variant = Image.composite(dark_patch, patch_rgb, opening_mask)
        variants.append(variant)

    return variants, (left, top, right, bottom), patch_mask


def render_lipsync_scene(
    scene: dict,
    output_path: Path,
    width: int,
    height: int,
    fps: int = 30,
    intensity: float = 1.0,
    progress: ProgressCallback | None = None,
) -> Path:
    """Render an audio-driven talking-head scene on CPU, without a neural lip-sync model."""
    progress = progress or (lambda _fraction, _message: None)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    image_path = Path(scene["image_path"])
    voice_wav = Path(scene["voice_wav"])
    duration = max(1.0, float(scene["duration"]))

    envelope = audio_envelope(voice_wav, fps=fps, duration=duration)
    base_frame, foreground, placement = compose_scene_frame(image_path, width, height)
    with Image.open(image_path) as original:
        original_size = original.size
    mouth_bbox = detect_mouth_bbox(image_path)
    frame_bbox = _map_bbox_to_frame(mouth_bbox, original_size, foreground.size, placement)
    variants, patch_box, patch_mask = _build_mouth_variants(base_frame, frame_bbox)
    levels = len(variants)

    frame_count = max(1, int(math.ceil(duration * fps)))
    writer = imageio_ffmpeg.write_frames(
        str(output_path),
        (width, height),
        fps=fps,
        codec="libx264",
        quality=8,
        pix_fmt_in="rgb24",
        pix_fmt_out="yuv420p",
        macro_block_size=1,
        ffmpeg_log_level="error",
        output_params=["-movflags", "+faststart"],
    )
    writer.send(None)
    try:
        for index in range(frame_count):
            t = index / fps
            envelope_value = float(envelope[min(index, len(envelope) - 1)])
            openness = max(0.0, min(1.0, envelope_value * max(0.2, float(intensity))))
            variant = variants[min(levels - 1, int(round(openness * (levels - 1))))]
            frame = base_frame.copy()
            frame.paste(variant, (patch_box[0], patch_box[1]), patch_mask)

            # Gentle luminance breathing keeps the frame from looking frozen.
            breathing = 1.0 + 0.006 * math.sin(t * 1.7)
            frame = ImageEnhance.Brightness(frame).enhance(breathing)

            fade_in = min(1.0, t / 0.35)
            fade_out = min(1.0, max(0.0, duration - t) / 0.45)
            fade = min(fade_in, fade_out)
            if fade < 1.0:
                frame = ImageEnhance.Brightness(frame).enhance(max(0.0, fade))
            writer.send(frame.tobytes())
            if index % 5 == 0 or index == frame_count - 1:
                progress(index / frame_count, f"Lip-sync frame {index + 1}/{frame_count}")
    finally:
        writer.close()
    progress(1.0, "Lip-sync render complete")
    return output_path
