from __future__ import annotations

import math
import re
import wave
from pathlib import Path
from typing import Callable

from .catalog import CATALOG, ensure_voice
from .subtitles import font_for_language, write_ass, write_srt

ProgressCallback = Callable[[float, str], None]

SENTENCE_SPLIT = re.compile(r"(?<=[.!?۔؟।。！？])\s+|\n+")
LONG_SPLIT = re.compile(r"(?<=[,،、;:])\s+")


def split_script(text: str, max_chars: int = 240) -> list[str]:
    text = (text or "").replace("\r\n", "\n").replace("\r", "\n").strip()
    if not text:
        return []
    rough = [part.strip() for part in SENTENCE_SPLIT.split(text) if part.strip()]
    sentences: list[str] = []
    for part in rough:
        if len(part) <= max_chars:
            sentences.append(part)
            continue
        pieces = [p.strip() for p in LONG_SPLIT.split(part) if p.strip()]
        if len(pieces) == 1:
            words = part.split()
            current = ""
            for word in words:
                candidate = f"{current} {word}".strip()
                if current and len(candidate) > max_chars:
                    sentences.append(current)
                    current = word
                else:
                    current = candidate
            if current:
                sentences.append(current)
        else:
            current = ""
            for piece in pieces:
                candidate = f"{current} {piece}".strip()
                if current and len(candidate) > max_chars:
                    sentences.append(current)
                    current = piece
                else:
                    current = candidate
            if current:
                sentences.append(current)
    return sentences


def partition_sentences(sentences: list[str], scene_count: int) -> list[list[str]]:
    scene_count = max(1, int(scene_count))
    if not sentences:
        return [[] for _ in range(scene_count)]
    if scene_count == 1:
        return [sentences]
    weights = [max(1, len(s)) for s in sentences]
    target = sum(weights) / scene_count
    groups: list[list[str]] = []
    current: list[str] = []
    current_weight = 0
    for sentence, weight in zip(sentences, weights):
        if current and current_weight + weight > target * 1.25 and len(groups) < scene_count - 1:
            groups.append(current)
            current = []
            current_weight = 0
        current.append(sentence)
        current_weight += weight
    if current:
        groups.append(current)
    while len(groups) < scene_count:
        # Move sentences from the longest group, or add an empty visual-only scene.
        longest = max(range(len(groups)), key=lambda i: len(groups[i]))
        if len(groups[longest]) > 1:
            groups.append([groups[longest].pop()])
        else:
            groups.append([])
    while len(groups) > scene_count:
        shortest = min(range(len(groups) - 1), key=lambda i: sum(len(s) for s in groups[i]))
        groups[shortest].extend(groups.pop())
    return groups[:scene_count]


def _silence_frames(wav: wave.Wave_write, seconds: float, params) -> None:
    frames = int(max(0.0, seconds) * params.framerate)
    wav.writeframes(b"\x00" * frames * params.nchannels * params.sampwidth)


def _read_wav(path: Path):
    with wave.open(str(path), "rb") as handle:
        params = handle.getparams()
        frames = handle.readframes(handle.getnframes())
    return params, frames


def synthesize_scenes(
    groups: list[list[str]],
    voice_key: str,
    output_dir: Path,
    speech_rate: float = 1.0,
    sentence_pause: float = 0.18,
    lead_in: float = 0.35,
    tail: float = 0.45,
    resolution: tuple[int, int] = (1920, 1080),
    voice_engine: str = "piper",
    reference_audio: Path | None = None,
    clone_language_id: str | None = None,
    clone_device: str = "auto",
    progress: ProgressCallback | None = None,
) -> dict:
    """Synthesize scene voiceovers with Piper or optional Chatterbox voice cloning."""
    progress = progress or (lambda _fraction, _message: None)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    temp_dir = output_dir / "segments"
    temp_dir.mkdir(exist_ok=True)

    voice_engine = (voice_engine or "piper").lower()
    sample_text = " ".join(s for group in groups for s in group)
    piper_locale = CATALOG.get(voice_key, {}).get("language", {}).get("code", "en_US")

    if voice_engine == "clone":
        from .voice_clone import (
            availability,
            get_model,
            install_instructions,
            locale_to_clone_language,
            resolve_device,
            synthesize_sentence,
        )

        status = availability()
        if not status["available"]:
            raise RuntimeError(
                "Voice cloning dependencies are not installed. Run:\n\n"
                + install_instructions()
                + f"\n\nDetails: {status['error']}"
            )
        if not reference_audio or not Path(reference_audio).exists():
            raise FileNotFoundError("A reference voice sample is required for voice cloning.")
        clone_language_id = (clone_language_id or locale_to_clone_language(piper_locale)).lower()
        device = resolve_device(clone_device)
        language = clone_language_id
        effective_voice_key = f"chatterbox-clone:{clone_language_id}"
        progress(0.04, "Loading Chatterbox voice cloning model (first run may download ~1–2 GB)…")
        get_model(device, progress)

        def synthesize_one(sentence: str, temp_wav: Path) -> None:
            synthesize_sentence(
                sentence,
                clone_language_id,
                Path(reference_audio),
                temp_wav,
                device=device,
            )
    else:
        model_path, _config_path = ensure_voice(voice_key, progress)
        from piper import PiperVoice, SynthesisConfig

        voice = PiperVoice.load(str(model_path))
        length_scale = 1.0 / max(0.5, min(2.0, float(speech_rate)))
        syn_config = SynthesisConfig(length_scale=length_scale, normalize_audio=True, volume=1.0)
        language = piper_locale
        effective_voice_key = voice_key

        def synthesize_one(sentence: str, temp_wav: Path) -> None:
            with wave.open(str(temp_wav), "wb") as tts_wav:
                voice.synthesize_wav(sentence, tts_wav, syn_config=syn_config)

    font_file, font_family = font_for_language(language, sample_text)

    total_sentences = max(1, sum(len(group) for group in groups))
    completed = 0
    scenes = []

    for scene_index, group in enumerate(groups):
        scene_wav_path = output_dir / f"scene_{scene_index:03d}.wav"
        scene_writer = None
        params = None
        position = 0.0
        subtitle_segments = []

        try:
            scene_writer = wave.open(str(scene_wav_path), "wb")
            for sentence_index, sentence in enumerate(group):
                temp_wav = temp_dir / f"s{scene_index:03d}_{sentence_index:03d}.wav"
                synthesize_one(sentence, temp_wav)
                chunk_params, chunk_frames = _read_wav(temp_wav)
                if params is None:
                    params = chunk_params
                    scene_writer.setnchannels(params.nchannels)
                    scene_writer.setsampwidth(params.sampwidth)
                    scene_writer.setframerate(params.framerate)
                    _silence_frames(scene_writer, lead_in, params)
                    position += lead_in
                elif (
                    chunk_params.framerate != params.framerate
                    or chunk_params.nchannels != params.nchannels
                    or chunk_params.sampwidth != params.sampwidth
                ):
                    raise RuntimeError("The TTS engine returned inconsistent WAV formats.")

                start = position
                scene_writer.writeframes(chunk_frames)
                chunk_duration = len(chunk_frames) / (
                    params.framerate * params.nchannels * params.sampwidth
                )
                position += chunk_duration
                subtitle_segments.append(
                    {"start": start, "end": position, "text": sentence}
                )
                _silence_frames(scene_writer, sentence_pause, params)
                position += sentence_pause
                completed += 1
                progress(
                    0.1 + 0.65 * completed / total_sentences,
                    f"Voiceover • sentence {completed}/{total_sentences}",
                )

            if params is None:
                # Empty visual-only scene: one second of silence.
                params = wave._wave_params(1, 2, 22050, 0, "NONE", "not compressed")
                scene_writer.setnchannels(params.nchannels)
                scene_writer.setsampwidth(params.sampwidth)
                scene_writer.setframerate(params.framerate)
                position = 1.0
            _silence_frames(scene_writer, tail, params)
            position += tail
        finally:
            if scene_writer is not None:
                scene_writer.close()

        scenes.append(
            {
                "index": scene_index,
                "voice_wav": scene_wav_path,
                "duration": position,
                "subtitle_segments": subtitle_segments,
            }
        )

    # Concatenate all scene WAVs into one full voice track.
    full_voice = output_dir / "voiceover.wav"
    first_params, _ = _read_wav(scenes[0]["voice_wav"])
    with wave.open(str(full_voice), "wb") as combined:
        combined.setnchannels(first_params.nchannels)
        combined.setsampwidth(first_params.sampwidth)
        combined.setframerate(first_params.framerate)
        for scene in scenes:
            params, frames = _read_wav(scene["voice_wav"])
            if (
                params.framerate != first_params.framerate
                or params.nchannels != first_params.nchannels
                or params.sampwidth != first_params.sampwidth
            ):
                raise RuntimeError("Scene WAV formats do not match.")
            combined.writeframes(frames)

    from .subtitles import global_segments

    segments = global_segments(scenes)
    total_duration = sum(scene["duration"] for scene in scenes)
    srt_path = write_srt(segments, output_dir / "subtitles.srt", language=language)
    ass_path = write_ass(segments, output_dir / "subtitles.ass", font_family, resolution[0], resolution[1])

    progress(0.8, "Voiceover and timed subtitles ready")
    return {
        "scenes": scenes,
        "full_voice_wav": full_voice,
        "total_duration": total_duration,
        "segments": segments,
        "srt_path": srt_path,
        "ass_path": ass_path,
        "font_file": font_file,
        "font_family": font_family,
        "language": language,
        "voice_key": effective_voice_key,
        "voice_engine": voice_engine,
    }
