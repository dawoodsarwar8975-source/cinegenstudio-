"""CineGen Studio — a free, local, multilingual AI video toolkit."""

__version__ = "2.1.0"
__app_name__ = "CineGen Studio"
