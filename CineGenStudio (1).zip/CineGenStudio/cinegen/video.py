from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import Callable

from .config import FFMPEG, FONT_DIR, ROOT, find_ffmpeg
from .subtitles import subtitle_filter

ProgressCallback = Callable[[float, str], None]

RESOLUTIONS = {
    "1080p": (1920, 1080),
    "720p": (1280, 720),
    "Vertical 1080x1920": (1080, 1920),
    "Square 1080x1080": (1080, 1080),
    "4K UHD": (3840, 2160),
}


def _relative(path: Path) -> str:
    path = Path(path)
    try:
        return path.resolve().relative_to(ROOT.resolve()).as_posix()
    except ValueError:
        return path.as_posix()


def _progress_ffmpeg(args: list[str], progress: ProgressCallback | None, duration: float) -> None:
    exe = find_ffmpeg()
    command = [exe, "-hide_banner", "-loglevel", "error", "-y", *args]
    if progress:
        command += ["-progress", "pipe:1", "-nostats"]
        process = subprocess.Popen(
            command,
            cwd=ROOT,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
        )
        tail: list[str] = []
        assert process.stdout is not None
        for line in process.stdout:
            tail.append(line)
            tail = tail[-80:]
            if line.startswith("out_time_ms="):
                try:
                    seconds = int(line.split("=", 1)[1].strip()) / 1_000_000
                    if duration > 0:
                        progress(min(0.99, seconds / duration), f"Rendering video • {seconds:.1f}s")
                except ValueError:
                    pass
        code = process.wait()
        if code != 0:
            raise RuntimeError("FFmpeg failed:\n" + "".join(tail[-40:]))
        progress(1.0, "Render complete")
    else:
        result = subprocess.run(
            command,
            cwd=ROOT,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        if result.returncode != 0:
            raise RuntimeError("FFmpeg failed:\n" + (result.stderr or result.stdout)[-4000:])


def _escape_filter_path(value: str) -> str:
    value = value.replace("\\", "/").replace(":", r"\:").replace("'", r"\'")
    return value


def _zoom_filter(style: str, intensity: float, duration: float, fps: int) -> tuple[str, str, str]:
    intensity = max(0.05, min(1.0, float(intensity)))
    frames = max(1, int(duration * fps))
    if style == "Cinematic Zoom":
        z = f"1.0+{0.11 * intensity:.4f}*on/{frames}"
    elif style == "Gentle Parallax":
        z = f"{1.035 + 0.015 * intensity:.4f}"
    elif style == "Dynamic":
        z = f"1.025+{0.045 * intensity:.4f}*sin(on/42)"
    else:
        z = f"1.025+{0.028 * intensity:.4f}*sin(on/58)"
    if style == "Gentle Parallax":
        x = f"iw/2-(iw/zoom/2)+sin(on/64)*{22 * intensity:.1f}"
        y = f"ih/2-(ih/zoom/2)+cos(on/76)*{13 * intensity:.1f}"
    else:
        x = "iw/2-(iw/zoom/2)"
        y = "ih/2-(ih/zoom/2)"
    return z, x, y


def render_standard_scene(
    scene: dict,
    output_path: Path,
    width: int,
    height: int,
    style: str = "Standard Studio",
    intensity: float = 0.5,
    fps: int = 30,
    progress: ProgressCallback | None = None,
) -> Path:
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    duration = max(1.0, float(scene["duration"]))
    bg = _relative(scene["background"])
    fg = _relative(scene["foreground"])
    z, x, y = _zoom_filter(style, intensity, duration, fps)
    fade_out = max(0.0, duration - 0.45)

    filter_graph = (
        f"[0:v]scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height},"
        f"eq=contrast=1.04:saturation=1.06:brightness=-0.01,gblur=sigma=14[bg];"
        f"[1:v]format=rgba,zoompan=z='{z}':x='{x}':y='{y}':d=1:s={width}x{height}:fps={fps},"
        f"format=rgba[fg];"
        f"[bg][fg]overlay=x='(W-w)/2+sin(t*0.63)*{8 * intensity:.1f}':"
        f"y='(H-h)/2+cos(t*0.52)*{5 * intensity:.1f}':format=auto,"
        f"eq=contrast=1.03:saturation=1.05:brightness=0.01,noise=alls=2:allf=t,"
        f"fade=t=in:st=0:d=0.35,fade=t=out:st={fade_out:.3f}:d=0.45,"
        f"fps={fps},format=yuv420p[v]"
    )
    args = [
        "-loop", "1", "-framerate", str(fps), "-t", f"{duration:.3f}", "-i", bg,
        "-loop", "1", "-framerate", str(fps), "-t", f"{duration:.3f}", "-i", fg,
        "-filter_complex", filter_graph,
        "-map", "[v]", "-an", "-t", f"{duration:.3f}",
        "-c:v", "libx264", "-preset", "medium", "-crf", "16",
        "-pix_fmt", "yuv420p", "-movflags", "+faststart",
        _relative(output_path),
    ]
    _progress_ffmpeg(args, progress, duration)
    return output_path


def loop_trim_clip(
    clip_path: Path,
    output_path: Path,
    duration: float,
    width: int,
    height: int,
    fps: int = 30,
    progress: ProgressCallback | None = None,
) -> Path:
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    duration = max(1.0, float(duration))
    fade_out = max(0.0, duration - 0.4)
    vf = (
        f"scale={width}:{height}:force_original_aspect_ratio=increase,"
        f"crop={width}:{height},fps={fps},eq=contrast=1.02:saturation=1.04,"
        f"fade=t=in:st=0:d=0.3,fade=t=out:st={fade_out:.3f}:d=0.4,format=yuv420p"
    )
    args = [
        "-stream_loop", "-1", "-i", _relative(clip_path),
        "-t", f"{duration:.3f}", "-vf", vf, "-an",
        "-c:v", "libx264", "-preset", "medium", "-crf", "18",
        "-pix_fmt", "yuv420p", "-movflags", "+faststart",
        _relative(output_path),
    ]
    _progress_ffmpeg(args, progress, duration)
    return output_path


def concat_scenes(scene_videos: list[Path], output_path: Path) -> Path:
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    concat_file = output_path.with_name(output_path.stem + "_concat.txt")
    lines = []
    for path in scene_videos:
        # Paths inside a concat list are resolved relative to the list file, not
        # the process CWD. Absolute POSIX-style paths avoid double-prefixing.
        absolute = Path(path).resolve().as_posix().replace("'", "'\\''")
        lines.append(f"file '{absolute}'")
    concat_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
    args = [
        "-f", "concat", "-safe", "0", "-i", _relative(concat_file),
        "-c", "copy", "-movflags", "+faststart", _relative(output_path),
    ]
    _progress_ffmpeg(args, None, 0)
    return output_path


def mux_final(
    silent_video: Path,
    voice_wav: Path,
    output_path: Path,
    duration: float,
    width: int,
    height: int,
    music_path: Path | None = None,
    music_volume: float = 0.15,
    subtitle_path: Path | None = None,
    fps: int = 30,
    progress: ProgressCallback | None = None,
) -> Path:
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    duration = max(1.0, float(duration))
    video_filter = (
        f"scale={width}:{height}:force_original_aspect_ratio=increase,"
        f"crop={width}:{height},fps={fps},format=yuv420p"
    )
    if subtitle_path:
        video_filter += "," + subtitle_filter(subtitle_path, FONT_DIR, ROOT)

    inputs = ["-i", _relative(silent_video), "-i", _relative(voice_wav)]
    audio_filters = ["[1:a]aresample=48000,volume=1.0[voice]"]
    if music_path and Path(music_path).exists():
        inputs += ["-stream_loop", "-1", "-i", _relative(music_path)]
        fade_out = max(0.0, duration - 1.0)
        audio_filters.append(
            f"[2:a]aresample=48000,volume={music_volume:.3f},"
            f"afade=t=in:st=0:d=0.8,afade=t=out:st={fade_out:.3f}:d=1.0," 
            f"atrim=duration={duration:.3f}[music]"
        )
        audio_filters.append("[voice][music]amix=inputs=2:duration=first:dropout_transition=0[a]")
    else:
        audio_filters.append("[voice]atrim=duration={:.3f},apad=pad_dur=0.2[a]".format(duration))

    args = [
        *inputs,
        "-filter_complex",
        f"[0:v]{video_filter}[v];" + ";".join(audio_filters),
        "-map", "[v]", "-map", "[a]",
        "-t", f"{duration:.3f}",
        "-c:v", "libx264", "-preset", "medium", "-crf", "18",
        "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
        "-ar", "48000", "-ac", "2", "-movflags", "+faststart",
        _relative(output_path),
    ]
    _progress_ffmpeg(args, progress, duration)
    return output_path
