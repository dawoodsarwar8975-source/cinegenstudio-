from __future__ import annotations

import time
import uuid
from pathlib import Path
from typing import Callable
from urllib.parse import urlencode

import requests

from .workflow import build_wan_prompt

ProgressCallback = Callable[[float, str], None]
VIDEO_EXTENSIONS = {".mp4", ".webm", ".mkv", ".mov", ".gif", ".avi"}


class ComfyClient:
    def __init__(self, base_url: str = "http://127.0.0.1:8188"):
        self.base_url = base_url.rstrip("/")
        self.client_id = str(uuid.uuid4())
        self.session = requests.Session()

    def _url(self, path: str) -> str:
        return f"{self.base_url}/{path.lstrip('/')}"

    def system_stats(self) -> dict:
        response = self.session.get(self._url("/system_stats"), timeout=10)
        response.raise_for_status()
        return response.json()

    def object_info(self) -> dict:
        response = self.session.get(self._url("/object_info"), timeout=30)
        response.raise_for_status()
        return response.json()

    def upload_image(self, image_path: Path) -> str:
        image_path = Path(image_path)
        with image_path.open("rb") as handle:
            files = {"image": (image_path.name, handle, "image/png")}
            data = {"overwrite": "true", "type": "input"}
            response = self.session.post(
                self._url("/upload/image"), files=files, data=data, timeout=120
            )
        response.raise_for_status()
        payload = response.json()
        name = payload.get("name") or image_path.name
        subfolder = payload.get("subfolder", "")
        return f"{subfolder}/{name}" if subfolder else name

    def queue_prompt(self, prompt: dict) -> str:
        body = {"prompt": prompt, "client_id": self.client_id}
        response = self.session.post(self._url("/prompt"), json=body, timeout=60)
        if response.status_code == 400:
            try:
                detail = response.json()
            except Exception:
                detail = response.text
            raise RuntimeError(f"ComfyUI rejected the workflow: {detail}")
        response.raise_for_status()
        payload = response.json()
        if "error" in payload:
            raise RuntimeError(f"ComfyUI workflow error: {payload['error']}")
        prompt_id = payload.get("prompt_id")
        if not prompt_id:
            raise RuntimeError("ComfyUI did not return a prompt_id.")
        return prompt_id

    def queue_position(self) -> int | None:
        try:
            response = self.session.get(self._url("/queue"), timeout=10)
            response.raise_for_status()
            data = response.json()
            running = data.get("queue_running", [])
            pending = data.get("queue_pending", [])
            return len(running) + len(pending)
        except Exception:
            return None

    def wait_for_history(
        self,
        prompt_id: str,
        timeout: int = 3600,
        poll_interval: float = 2.0,
        progress: ProgressCallback | None = None,
    ) -> dict:
        start = time.time()
        while True:
            elapsed = time.time() - start
            if elapsed > timeout:
                raise TimeoutError("ComfyUI generation timed out.")
            response = self.session.get(self._url(f"/history/{prompt_id}"), timeout=20)
            response.raise_for_status()
            data = response.json()
            if prompt_id in data:
                history = data[prompt_id]
                status = history.get("status", {})
                if status.get("status_str") == "error":
                    messages = status.get("messages", [])
                    raise RuntimeError(f"ComfyUI generation failed: {messages[-3:]}")
                if history.get("outputs"):
                    if progress:
                        progress(0.95, "AI generation finished; downloading clip…")
                    return history
            position = self.queue_position()
            if progress:
                message = "Waiting for ComfyUI…"
                if position:
                    message += f" Queue: {position} job(s)."
                message += f" Elapsed {int(elapsed)}s."
                progress(min(0.9, 0.05 + elapsed / max(1.0, timeout) * 0.8), message)
            time.sleep(poll_interval)

    def download_outputs(self, history: dict, destination_dir: Path) -> list[Path]:
        destination_dir = Path(destination_dir)
        destination_dir.mkdir(parents=True, exist_ok=True)
        downloaded: list[Path] = []
        for _node_id, node_output in history.get("outputs", {}).items():
            for key in ("images", "gifs", "videos", "audio_ui"):
                for item in node_output.get(key, []) or []:
                    filename = item.get("filename") or item.get("name")
                    if not filename:
                        continue
                    suffix = Path(filename).suffix.lower()
                    if suffix not in VIDEO_EXTENSIONS:
                        continue
                    params = {
                        "filename": filename,
                        "subfolder": item.get("subfolder", ""),
                        "type": item.get("type", "output"),
                    }
                    url = self._url("/view") + "?" + urlencode(params)
                    response = self.session.get(url, timeout=300)
                    response.raise_for_status()
                    target = destination_dir / Path(filename).name
                    target.write_bytes(response.content)
                    downloaded.append(target)
        return downloaded

    def generate_clip(
        self,
        image_path: Path,
        config: dict,
        destination_dir: Path,
        progress: ProgressCallback | None = None,
        timeout: int = 3600,
    ) -> Path:
        progress = progress or (lambda _fraction, _message: None)
        progress(0.02, "Uploading character image to ComfyUI…")
        image_name = self.upload_image(image_path)
        config = dict(config)
        config["image_name"] = image_name
        prompt = build_wan_prompt(config)
        progress(0.05, "Submitting Wan2.2 image-to-video job…")
        prompt_id = self.queue_prompt(prompt)
        history = self.wait_for_history(prompt_id, timeout=timeout, progress=progress)
        clips = self.download_outputs(history, destination_dir)
        if not clips:
            raise RuntimeError(
                "ComfyUI finished but no MP4/WebM output was found. "
                "Check that the SaveVideo node is enabled in the workflow."
            )
        progress(1.0, "AI clip downloaded")
        return clips[0]
