from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageFilter, ImageOps


def _open_image(path: Path) -> Image.Image:
    image = Image.open(path)
    image = ImageOps.exif_transpose(image)
    return image.convert("RGBA")


def _cinematic_background(image: Image.Image, width: int, height: int) -> Image.Image:
    base = ImageOps.fit(
        image.convert("RGB"),
        (width, height),
        method=Image.Resampling.LANCZOS,
        centering=(0.5, 0.5),
    )
    blur = max(10, int(width * 0.018))
    base = base.filter(ImageFilter.GaussianBlur(blur))
    base = ImageEnhance.Brightness(base).enhance(0.58)
    base = ImageEnhance.Color(base).enhance(0.82)
    tint = Image.new("RGBA", (width, height), (10, 16, 34, 40))
    base = Image.alpha_composite(base.convert("RGBA"), tint)

    # A subtle top-to-bottom darkening keeps captions readable.
    gradient = Image.new("L", (1, height), 0)
    for y in range(height):
        gradient.putpixel((0, y), int(72 * (y / max(1, height - 1)) ** 1.4))
    gradient = gradient.resize((width, height))
    shade = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    shade.putalpha(gradient)
    return Image.alpha_composite(base, shade).convert("RGB")


def _fit_foreground(image: Image.Image, width: int, height: int) -> Image.Image:
    max_w = int(width * 0.78)
    max_h = int(height * 0.86)
    fg = image.copy()
    fg.thumbnail((max_w, max_h), Image.Resampling.LANCZOS)

    # Feather the border so square character images blend into the widescreen
    # background instead of showing a hard rectangular cutout.
    alpha = fg.getchannel("A")
    mask = Image.new("L", fg.size, 0)
    draw = ImageDraw.Draw(mask)
    radius = max(12, int(min(fg.size) * 0.07))
    draw.rounded_rectangle((0, 0, fg.width - 1, fg.height - 1), radius=radius, fill=255)
    blur = max(8, int(min(fg.size) * 0.035))
    mask = mask.filter(ImageFilter.GaussianBlur(blur))
    fg.putalpha(ImageChops.multiply(alpha, mask))
    return fg


def prepare_scene_assets(
    image_path: Path,
    output_dir: Path,
    width: int,
    height: int,
) -> tuple[Path, Path]:
    """Create a blurred cinematic background and a transparent foreground layer."""
    image_path = Path(image_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    source = _open_image(image_path)
    background = _cinematic_background(source, width, height)
    fg = _fit_foreground(source, width, height)

    canvas = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    x = (width - fg.width) // 2
    y = (height - fg.height) // 2

    # Soft drop shadow.
    alpha = fg.getchannel("A")
    shadow = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    shadow_alpha = alpha.filter(ImageFilter.GaussianBlur(max(12, int(width * 0.014))))
    shadow_layer = Image.new("RGBA", fg.size, (0, 0, 0, 130))
    shadow_layer.putalpha(shadow_alpha.point(lambda p: int(p * 0.55)))
    shadow.alpha_composite(shadow_layer, (x + int(width * 0.012), y + int(height * 0.018)))
    canvas = Image.alpha_composite(canvas, shadow)
    canvas.alpha_composite(fg, (x, y))

    bg_path = output_dir / "background.png"
    fg_path = output_dir / "foreground.png"
    background.save(bg_path, optimize=True)
    canvas.save(fg_path, optimize=True)
    return bg_path, fg_path


def prepare_ai_input(image_path: Path, output_path: Path, width: int, height: int) -> Path:
    """Create a clean RGB start frame for ComfyUI image-to-video."""
    image_path = Path(image_path)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    source = _open_image(image_path)
    background = _cinematic_background(source, width, height).convert("RGBA")
    fg = _fit_foreground(source, width, height)
    x = (width - fg.width) // 2
    y = (height - fg.height) // 2
    background.alpha_composite(fg, (x, y))
    background.convert("RGB").save(output_path, quality=94)
    return output_path


def compose_scene_frame(
    image_path: Path,
    width: int,
    height: int,
) -> tuple[Image.Image, Image.Image, tuple[int, int]]:
    """Return a full RGB frame, the fitted foreground and its top-left placement.

    The placement lets other renderers (for example the lip-sync engine) map
    coordinates detected on the original character image into the final frame.
    """
    source = _open_image(Path(image_path))
    background = _cinematic_background(source, width, height).convert("RGBA")
    foreground = _fit_foreground(source, width, height)
    x = (width - foreground.width) // 2
    y = (height - foreground.height) // 2

    shadow = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    shadow_alpha = foreground.getchannel("A").filter(
        ImageFilter.GaussianBlur(max(12, int(width * 0.014)))
    )
    shadow_layer = Image.new("RGBA", foreground.size, (0, 0, 0, 110))
    shadow_layer.putalpha(shadow_alpha.point(lambda p: int(p * 0.45)))
    shadow.alpha_composite(shadow_layer, (x + int(width * 0.012), y + int(height * 0.018)))
    frame = Image.alpha_composite(background, shadow)
    frame.alpha_composite(foreground, (x, y))
    return frame.convert("RGB"), foreground, (x, y)


def make_placeholder_character(output_path: Path, size: int = 1024) -> Path:
    """A lightweight fallback character image for demos and tests."""
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    image = Image.new("RGB", (size, size), (24, 29, 54))
    draw = ImageDraw.Draw(image)
    draw.ellipse((size * 0.28, size * 0.17, size * 0.72, size * 0.65), fill=(238, 190, 152))
    draw.ellipse((size * 0.24, size * 0.1, size * 0.76, size * 0.42), fill=(38, 32, 45))
    draw.rounded_rectangle(
        (size * 0.22, size * 0.62, size * 0.78, size * 1.05),
        radius=int(size * 0.08),
        fill=(77, 113, 213),
    )
    draw.ellipse((size * 0.4, size * 0.34, size * 0.43, size * 0.37), fill=(35, 35, 45))
    draw.ellipse((size * 0.57, size * 0.34, size * 0.6, size * 0.37), fill=(35, 35, 45))
    draw.arc((size * 0.44, size * 0.42, size * 0.56, size * 0.51), 20, 160, fill=(120, 55, 65), width=6)
    image.save(output_path)
    return output_path
