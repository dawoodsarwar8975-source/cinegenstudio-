from __future__ import annotations

import json
from pathlib import Path
from typing import Callable

import requests

from .config import PRO_MODELS_PATH
from .downloader import download_file, ensure_minimum_disk_space, human_size

ProgressCallback = Callable[[float, str], None]


def load_pro_models() -> dict:
    with PRO_MODELS_PATH.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def remote_size(url: str) -> int | None:
    try:
        response = requests.head(url, allow_redirects=True, timeout=30)
        response.raise_for_status()
        return int(response.headers.get("Content-Length", "0")) or None
    except Exception:
        return None


def validate_comfy_path(comfy_path: Path) -> Path:
    comfy_path = Path(comfy_path).expanduser().resolve()
    if not comfy_path.exists():
        raise FileNotFoundError(f"ComfyUI folder does not exist: {comfy_path}")
    looks_like_comfy = (comfy_path / "main.py").exists() or (comfy_path / "models").exists()
    if not looks_like_comfy:
        raise RuntimeError(
            f"{comfy_path} does not look like a ComfyUI folder. "
            "Select the folder that contains main.py and the models directory."
        )
    return comfy_path


def check_pro_models(comfy_path: Path) -> list[dict]:
    comfy_path = Path(comfy_path).expanduser()
    data = load_pro_models()
    report = []
    for model in data["models"]:
        path = comfy_path / model["dest_folder"] / model["filename"]
        part = path.with_name(path.name + ".part")
        report.append(
            {
                "name": model["name"],
                "filename": model["filename"],
                "installed": path.exists() and path.stat().st_size > 100_000_000,
                "size": human_size(path.stat().st_size) if path.exists() else "—",
                "partial": part.exists(),
                "path": str(path),
            }
        )
    return report


def install_pro_models(
    comfy_path: Path,
    progress: ProgressCallback | None = None,
) -> list[Path]:
    progress = progress or (lambda _fraction, _message: None)
    comfy_path = validate_comfy_path(comfy_path)
    data = load_pro_models()
    models = data["models"]
    ensure_minimum_disk_space(comfy_path, int(data.get("approx_total_gb", 18) * (1024**3)))

    installed: list[Path] = []
    total_weight = sum(model.get("approx_gb", 1.0) for model in models)
    weight_done = 0.0
    for index, model in enumerate(models, start=1):
        target_dir = comfy_path / model["dest_folder"]
        target_dir.mkdir(parents=True, exist_ok=True)
        target = target_dir / model["filename"]
        if target.exists() and target.stat().st_size > 100_000_000:
            weight_done += model.get("approx_gb", 1.0)
            progress(weight_done / total_weight, f"Already installed: {model['name']}")
            installed.append(target)
            continue
        expected = remote_size(model["url"])
        weight = model.get("approx_gb", 1.0)

        def local_progress(fraction: float, message: str, _weight: float = weight) -> None:
            overall = (weight_done + _weight * fraction) / total_weight
            progress(overall, f"{model['name']} ({index}/{len(models)}) — {message}")

        download_file(
            model["url"],
            target,
            progress=local_progress,
            expected_size=expected,
        )
        weight_done += weight
        installed.append(target)
    progress(1.0, "All Wan2.2 Pro model files are ready.")
    return installed
