from __future__ import annotations

import uuid
import wave
from datetime import datetime
from pathlib import Path
from typing import Callable

from .config import ASSETS_DIR, OUTPUT_DIR, WORK_DIR
from .imaging import make_placeholder_character, prepare_scene_assets
from .lipsync import render_lipsync_scene
from .subtitles import write_ass, write_srt
from .tts import split_script, synthesize_scenes
from .video import (
    RESOLUTIONS,
    concat_scenes,
    loop_trim_clip,
    mux_final,
    render_standard_scene,
)

ProgressCallback = Callable[[float, str], None]

CHAT_STYLES = [
    "Lip Sync Avatar",
    "Standard Studio",
    "Cinematic Zoom",
    "Gentle Parallax",
    "Dynamic",
]


def new_project() -> dict:
    job_id = datetime.now().strftime("%Y%m%d_%H%M%S") + "_chat_" + uuid.uuid4().hex[:6]
    job_dir = WORK_DIR / job_id
    (job_dir / "sections").mkdir(parents=True, exist_ok=True)
    return {"job_id": job_id, "job_dir": str(job_dir), "sections": []}


def _ensure_state(state: dict | None) -> dict:
    if state and isinstance(state, dict) and "job_dir" in state:
        return state
    return new_project()


def _fallback_character() -> Path:
    sample = ASSETS_DIR / "sample_character.png"
    if not sample.exists():
        make_placeholder_character(sample)
    return sample


def generate_section(
    state: dict | None,
    message: str,
    image_paths: list,
    voice_key: str,
    style: str = "Lip Sync Avatar",
    resolution_name: str = "720p",
    intensity: float = 0.8,
    speed: float = 1.0,
    subtitles: bool = True,
    progress: ProgressCallback | None = None,
) -> dict:
    """Turn one chat message into one animated, playable video section."""
    state = _ensure_state(state)
    job_dir = Path(state["job_dir"])
    index = len(state["sections"])
    sec_dir = job_dir / "sections" / f"sec_{index:03d}"
    width, height = RESOLUTIONS[resolution_name]

    sentences = split_script(message)
    if not sentences:
        raise ValueError("The message did not contain any speakable text.")

    tts = synthesize_scenes(
        groups=[sentences],
        voice_key=voice_key,
        output_dir=sec_dir / "audio",
        speech_rate=speed,
        resolution=(width, height),
        progress=progress,
    )
    scene = tts["scenes"][0]

    if image_paths:
        image_path = Path(image_paths[index % len(image_paths)])
    else:
        image_path = _fallback_character()

    if style == "Lip Sync Avatar":
        scene["image_path"] = image_path
        silent = render_lipsync_scene(
            scene,
            sec_dir / "silent.mp4",
            width,
            height,
            intensity=intensity,
            progress=progress,
        )
    else:
        background, foreground = prepare_scene_assets(image_path, sec_dir / "assets", width, height)
        scene["background"] = background
        scene["foreground"] = foreground
        silent = render_standard_scene(
            scene,
            sec_dir / "silent.mp4",
            width,
            height,
            style=style,
            intensity=intensity,
            progress=progress,
        )

    subtitle_path = None
    if subtitles:
        subtitle_path = write_ass(
            tts["segments"],
            sec_dir / "audio" / "subtitles.ass",
            tts["font_family"],
            width,
            height,
        )

    section_video = mux_final(
        silent_video=silent,
        voice_wav=tts["full_voice_wav"],
        output_path=sec_dir / f"section_{index:03d}.mp4",
        duration=scene["duration"],
        width=width,
        height=height,
        subtitle_path=subtitle_path,
        progress=progress,
    )

    entry = {
        "index": index,
        "silent": str(silent),
        "video": str(section_video),
        "wav": str(tts["full_voice_wav"]),
        "duration": scene["duration"],
        "segments": tts["segments"],
        "font_family": tts["font_family"],
        "width": width,
        "height": height,
        "sentences": len(sentences),
        "image": str(image_path),
    }
    state["sections"].append(entry)
    return entry


def _concat_wavs(wav_paths: list, output_path: Path) -> Path:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    base = None
    with wave.open(str(output_path), "wb") as out:
        for wav_path in wav_paths:
            with wave.open(str(wav_path), "rb") as handle:
                params = handle.getparams()
                if base is None:
                    base = params
                    out.setnchannels(params.nchannels)
                    out.setsampwidth(params.sampwidth)
                    out.setframerate(params.framerate)
                elif (
                    params.framerate != base.framerate
                    or params.nchannels != base.nchannels
                    or params.sampwidth != base.sampwidth
                ):
                    raise RuntimeError("Section audio formats do not match.")
                out.writeframes(handle.readframes(handle.getnframes()))
    return output_path


def combine_sections(
    state: dict | None,
    resolution_name: str = "720p",
    music_path=None,
    music_volume: float = 0.15,
    subtitles: bool = True,
    progress: ProgressCallback | None = None,
) -> dict:
    """Concatenate all chat sections into one final subtitled video."""
    if not state or not state.get("sections"):
        raise RuntimeError("No sections yet. Send at least one script message first.")
    job_dir = Path(state["job_dir"])
    width, height = RESOLUTIONS[resolution_name]

    normalized = []
    for entry in state["sections"]:
        silent = Path(entry["silent"])
        if entry["width"] == width and entry["height"] == height:
            normalized.append(silent)
        else:
            target = job_dir / f"norm_{entry['index']:03d}.mp4"
            normalized.append(
                loop_trim_clip(
                    silent,
                    target,
                    entry["duration"],
                    width,
                    height,
                    progress=progress,
                )
            )

    combined_silent = concat_scenes(normalized, job_dir / "combined_silent.mp4")
    full_voice = _concat_wavs(
        [entry["wav"] for entry in state["sections"]],
        job_dir / "voiceover_all.wav",
    )

    segments = []
    offset = 0.0
    for entry in state["sections"]:
        for segment in entry["segments"]:
            segments.append(
                {
                    "start": offset + segment["start"],
                    "end": offset + segment["end"],
                    "text": segment["text"],
                }
            )
        offset += entry["duration"]
    total = offset

    font = state["sections"][0].get("font_family", "Noto Sans")
    ass_path = write_ass(segments, job_dir / "subtitles.ass", font, width, height)
    srt_path = write_srt(segments, job_dir / "subtitles.srt")

    final_path = OUTPUT_DIR / f"CineGen_Chat_{state['job_id']}.mp4"
    mux_final(
        silent_video=combined_silent,
        voice_wav=full_voice,
        output_path=final_path,
        duration=total,
        width=width,
        height=height,
        music_path=music_path,
        music_volume=music_volume,
        subtitle_path=ass_path if subtitles else None,
        progress=progress,
    )
    return {
        "final": str(final_path),
        "srt": str(srt_path),
        "duration": total,
        "count": len(state["sections"]),
    }
