from __future__ import annotations

import json
import os
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP_DIR = ROOT / "cinegen"
ASSETS_DIR = ROOT / "assets"
FONT_DIR = ASSETS_DIR / "fonts"
DATA_DIR = ROOT / "data"
WORKFLOW_DIR = ROOT / "workflows"
MODEL_DIR = ROOT / "models"
VOICE_MODEL_DIR = MODEL_DIR / "voices"
WORK_DIR = ROOT / "work"
OUTPUT_DIR = ROOT / "outputs"
EXAMPLE_DIR = ROOT / "examples"
SETTINGS_PATH = ROOT / "settings.json"
VOICE_CATALOG_PATH = DATA_DIR / "voices_catalog.json"
PRO_MODELS_PATH = DATA_DIR / "pro_models.json"
DEFAULT_WORKFLOW_PATH = WORKFLOW_DIR / "wan22_5b_i2v.json"

for directory in (
    ASSETS_DIR,
    FONT_DIR,
    DATA_DIR,
    WORKFLOW_DIR,
    MODEL_DIR,
    VOICE_MODEL_DIR,
    WORK_DIR,
    OUTPUT_DIR,
    EXAMPLE_DIR,
):
    directory.mkdir(parents=True, exist_ok=True)


DEFAULT_SETTINGS = {
    "comfy_url": "http://127.0.0.1:8188",
    "comfy_path": "",
    "last_language": "en_US",
    "last_voice": "en_US-amy-medium",
    "last_voice_engine": "Piper preset voices",
    "last_clone_language": "en",
    "last_clone_device": "auto",
    "last_resolution": "1080p",
    "last_mode": "Standard Studio",
    "last_voice_speed": 1.0,
    "last_music_volume": 0.15,
    "last_motion_intensity": 0.5,
    "last_motion_prompt": (
        "A polished cinematic portrait animation of the character in the reference image. "
        "Natural facial expression, subtle head movement, gentle breathing, professional studio lighting, "
        "smooth camera motion, detailed background, high production value."
    ),
    "last_negative_prompt": (
        "blurry, low quality, distorted face, deformed hands, extra fingers, extra limbs, text, watermark, "
        "flicker, jitter, melting face, duplicate person, oversaturated, static frame"
    ),
}


def load_settings() -> dict:
    settings = dict(DEFAULT_SETTINGS)
    try:
        if SETTINGS_PATH.exists():
            settings.update(json.loads(SETTINGS_PATH.read_text(encoding="utf-8")))
    except Exception:
        pass
    return settings


def save_settings(new_values: dict) -> dict:
    settings = load_settings()
    settings.update({k: v for k, v in new_values.items() if v is not None})
    SETTINGS_PATH.write_text(json.dumps(settings, ensure_ascii=False, indent=2), encoding="utf-8")
    return settings


def find_ffmpeg() -> str:
    """Return a usable ffmpeg executable.

    imageio-ffmpeg ships a static binary on Windows, Linux and macOS, so the app does
    not require a system-wide FFmpeg installation.
    """
    custom = os.environ.get("IMAGEIO_FFMPEG_EXE")
    if custom and Path(custom).exists():
        return custom
    try:
        import imageio_ffmpeg

        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        exe = shutil.which("ffmpeg")
        if exe:
            return exe
    raise RuntimeError(
        "FFmpeg not found. Install it with `pip install imageio-ffmpeg` or set IMAGEIO_FFMPEG_EXE."
    )


FFMPEG = find_ffmpeg()
PYTHON_VERSION = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
