from __future__ import annotations

import math
import shutil
import time
from pathlib import Path
from typing import Callable

import requests

ProgressCallback = Callable[[float, str], None]


def human_size(num_bytes: float) -> str:
    if num_bytes < 1024:
        return f"{int(num_bytes)} B"
    units = ["KB", "MB", "GB", "TB"]
    value = float(num_bytes)
    unit = "B"
    for unit in units:
        value /= 1024.0
        if value < 1024.0:
            break
    return f"{value:.1f} {unit}"


def no_op_progress(_: float, __: str) -> None:
    return None


def disk_free_bytes(path: Path) -> int:
    path.mkdir(parents=True, exist_ok=True)
    return shutil.disk_usage(path).free


def download_file(
    url: str,
    destination: Path,
    progress: ProgressCallback | None = None,
    chunk_size: int = 1024 * 1024,
    timeout: int = 60,
    expected_size: int | None = None,
) -> Path:
    """Stream a file with a resumable .part download."""
    progress = progress or no_op_progress
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    part = destination.with_name(destination.name + ".part")

    existing = part.stat().st_size if part.exists() else 0
    headers = {"Range": f"bytes={existing}-"} if existing else {}
    response = requests.get(url, stream=True, headers=headers, timeout=timeout)

    if response.status_code == 200:
        mode = "wb"
        existing = 0
    elif response.status_code == 206:
        mode = "ab"
    else:
        response.raise_for_status()
        mode = "wb"
        existing = 0

    total = expected_size or 0
    content_range = response.headers.get("Content-Range")
    if content_range and "/" in content_range:
        try:
            total = int(content_range.rsplit("/", 1)[1])
        except ValueError:
            pass
    if not total:
        total = int(response.headers.get("Content-Length", "0")) + existing

    downloaded = existing
    last_report = 0.0
    start = time.time()
    with part.open(mode) as handle:
        for chunk in response.iter_content(chunk_size=chunk_size):
            if not chunk:
                continue
            handle.write(chunk)
            downloaded += len(chunk)
            now = time.time()
            if total and (now - last_report > 0.25 or downloaded >= total):
                fraction = min(1.0, downloaded / total)
                elapsed = max(0.1, now - start)
                speed = max(0.0, downloaded - existing) / elapsed
                eta_seconds = max(0.0, (total - downloaded) / speed) if speed else 0
                eta = f"{int(eta_seconds // 60)}m {int(eta_seconds % 60)}s" if eta_seconds else "—"
                progress(
                    fraction,
                    f"{human_size(downloaded)} / {human_size(total)} • {human_size(speed)}/s • ETA {eta}",
                )
                last_report = now

    actual_size = part.stat().st_size
    if expected_size and actual_size != expected_size:
        part.unlink(missing_ok=True)
        raise RuntimeError(
            f"Downloaded file size mismatch: got {actual_size}, expected {expected_size}."
        )

    part.replace(destination)
    progress(1.0, f"Downloaded {human_size(destination.stat().st_size)}")
    return destination


def ensure_minimum_disk_space(path: Path, required_bytes: int) -> None:
    free = disk_free_bytes(path)
    if free < required_bytes:
        needed = human_size(required_bytes)
        have = human_size(free)
        raise RuntimeError(f"Not enough disk space. Need at least {needed}, but only {have} is free.")
