from __future__ import annotations

import copy
import json
import random
from pathlib import Path

from .config import DEFAULT_WORKFLOW_PATH

# Maps the official ComfyUI workflow's widget order to API input names.
# None means a UI-only widget that must not be sent to /prompt.
WIDGET_SCHEMAS = {
    "UNETLoader": ["unet_name", "weight_dtype"],
    "CLIPLoader": ["clip_name", "type", "device"],
    "VAELoader": ["vae_name"],
    "VAEDecode": [],
    "CreateVideo": ["fps"],
    "SaveVideo": ["filename_prefix", "format", "codec"],
    "Wan22ImageToVideoLatent": ["width", "height", "length", "batch_size"],
    "LoadImage": ["image", None],
    "CLIPTextEncode": ["text"],
    "KSampler": ["seed", None, "steps", "cfg", "sampler_name", "scheduler", "denoise"],
    "ModelSamplingSD3": ["shift"],
}

SKIP_TYPES = {"MarkdownNote", "Note", "PreviewAny", "PrimitiveNode"}


def load_ui_workflow(path: Path | None = None) -> dict:
    path = Path(path or DEFAULT_WORKFLOW_PATH)
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def ui_to_api(workflow: dict) -> dict:
    """Convert a ComfyUI UI-format workflow to the /prompt API format."""
    link_map: dict[int, list] = {}
    for link in workflow.get("links", []):
        # [link_id, origin_node_id, origin_slot, target_node_id, target_slot, type]
        if len(link) >= 3:
            link_map[int(link[0])] = [str(link[1]), int(link[2])]

    api: dict[str, dict] = {}
    for node in workflow.get("nodes", []):
        node_type = node.get("type")
        if not node_type or node_type in SKIP_TYPES:
            continue
        inputs: dict = {}
        for input_spec in node.get("inputs", []):
            name = input_spec.get("name")
            link = input_spec.get("link")
            if name and link is not None and int(link) in link_map:
                inputs[name] = link_map[int(link)]

        widgets = node.get("widgets_values", []) or []
        schema = WIDGET_SCHEMAS.get(node_type)
        if schema is not None:
            for name, value in zip(schema, widgets):
                if name is None or value is None:
                    continue
                inputs[name] = value
        elif widgets:
            # Unknown nodes are allowed only if all their widgets can be ignored.
            # This keeps the converter strict enough to catch real workflow changes.
            ignored = {"MarkdownNote", "Note"}
            if node_type not in ignored:
                raise ValueError(
                    f"No widget schema for node type '{node_type}'. "
                    "Update WIDGET_SCHEMAS after inspecting the workflow."
                )

        api[str(node["id"])] = {
            "class_type": node_type,
            "inputs": inputs,
            "_meta": {"title": node.get("title") or node_type},
        }
    return api


def find_nodes(prompt: dict, class_type: str) -> list[str]:
    return [node_id for node_id, node in prompt.items() if node.get("class_type") == class_type]


def adjust_frame_length(length: int) -> int:
    """Wan2.2 length uses step 4 starting at 1: 1, 5, 9, ..."""
    length = max(25, min(121, int(length)))
    return 4 * round((length - 1) / 4) + 1


def build_wan_prompt(config: dict) -> dict:
    """Build and patch the Wan2.2 5B image-to-video API workflow."""
    prompt = copy.deepcopy(ui_to_api(load_ui_workflow()))

    loaders = find_nodes(prompt, "LoadImage")
    if not loaders:
        raise RuntimeError("Bundled workflow has no LoadImage node.")
    prompt[loaders[0]]["inputs"]["image"] = config["image_name"]

    text_nodes = find_nodes(prompt, "CLIPTextEncode")
    if len(text_nodes) < 2:
        raise RuntimeError("Bundled workflow needs positive and negative CLIPTextEncode nodes.")
    # The official template uses node 6 for positive and node 7 for negative.
    positive_id = "6" if "6" in text_nodes else text_nodes[0]
    negative_id = "7" if "7" in text_nodes else text_nodes[1]
    prompt[positive_id]["inputs"]["text"] = config["positive_prompt"]
    prompt[negative_id]["inputs"]["text"] = config["negative_prompt"]

    latent_nodes = find_nodes(prompt, "Wan22ImageToVideoLatent")
    if not latent_nodes:
        raise RuntimeError("Bundled workflow has no Wan22ImageToVideoLatent node.")
    prompt[latent_nodes[0]]["inputs"].update(
        {
            "width": int(config["width"]),
            "height": int(config["height"]),
            "length": adjust_frame_length(config["length"]),
            "batch_size": 1,
        }
    )

    sampler_nodes = find_nodes(prompt, "KSampler")
    if sampler_nodes:
        prompt[sampler_nodes[0]]["inputs"].update(
            {
                "seed": int(config.get("seed") or random.randint(1, 2**31 - 1)),
                "steps": int(config.get("steps", 20)),
                "cfg": float(config.get("cfg", 5.0)),
                "denoise": 1.0,
            }
        )

    create_nodes = find_nodes(prompt, "CreateVideo")
    if create_nodes:
        prompt[create_nodes[0]]["inputs"]["fps"] = float(config.get("fps", 24))

    save_nodes = find_nodes(prompt, "SaveVideo")
    if save_nodes:
        save_inputs = prompt[save_nodes[0]]["inputs"]
        save_inputs["filename_prefix"] = config["filename_prefix"]
        save_inputs["format"] = "mp4"
        # In current ComfyUI, codec is a hidden dynamic combo. Omitting it lets
        # SaveVideo choose a compatible H.264/auto stream.
        save_inputs.pop("codec", None)
        save_inputs.pop("format.codec", None)

    for node_id, node in prompt.items():
        if node["class_type"] == "UNETLoader":
            node["inputs"]["unet_name"] = config.get(
                "unet_name", "wan2.2_ti2v_5B_fp16.safetensors"
            )
        elif node["class_type"] == "CLIPLoader":
            node["inputs"]["clip_name"] = config.get(
                "clip_name", "umt5_xxl_fp8_e4m3fn_scaled.safetensors"
            )
            node["inputs"]["type"] = "wan"
        elif node["class_type"] == "VAELoader":
            node["inputs"]["vae_name"] = config.get("vae_name", "wan2.2_vae.safetensors")
        elif node["class_type"] == "ModelSamplingSD3":
            node["inputs"]["shift"] = float(config.get("shift", 8.0))

    # _meta is accepted by ComfyUI but not needed by /prompt.
    return {node_id: {k: v for k, v in node.items() if k != "_meta"} for node_id, node in prompt.items()}
