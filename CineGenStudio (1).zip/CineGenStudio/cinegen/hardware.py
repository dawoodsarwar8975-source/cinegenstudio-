from __future__ import annotations

import platform
import shutil
import subprocess
from pathlib import Path

import psutil
import requests

from .config import FFMPEG, PYTHON_VERSION, ROOT, find_ffmpeg


def nvidia_gpus() -> list[dict]:
    exe = shutil.which("nvidia-smi")
    if not exe:
        return []
    try:
        result = subprocess.run(
            [
                exe,
                "--query-gpu=name,memory.total,driver_version",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
        gpus = []
        for line in result.stdout.strip().splitlines():
            parts = [p.strip() for p in line.split(",")]
            if len(parts) >= 3:
                gpus.append(
                    {
                        "name": parts[0],
                        "vram_mb": int(float(parts[1])),
                        "driver": parts[2],
                    }
                )
        return gpus
    except Exception:
        return []


def ffmpeg_version() -> str:
    try:
        result = subprocess.run(
            [find_ffmpeg(), "-hide_banner", "-version"],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
        return result.stdout.splitlines()[0] if result.stdout else "Unknown"
    except Exception:
        return "Unknown"


def comfy_status(url: str) -> dict:
    url = url.rstrip("/")
    try:
        response = requests.get(f"{url}/system_stats", timeout=5)
        response.raise_for_status()
        data = response.json()
        devices = data.get("devices", [])
        return {
            "online": True,
            "version": data.get("system", {}).get("comfyui_version", "unknown"),
            "devices": devices,
        }
    except Exception as exc:
        return {"online": False, "error": str(exc)}


def system_report() -> dict:
    memory = psutil.virtual_memory()
    disk = shutil.disk_usage(ROOT)
    gpus = nvidia_gpus()
    machine = platform.machine().lower()
    system = platform.system()
    apple_silicon = system == "Darwin" and machine in {"arm64", "aarch64"}
    return {
        "os": f"{system} {platform.release()}",
        "architecture": machine,
        "python": PYTHON_VERSION,
        "cpu_cores": psutil.cpu_count(logical=True),
        "ram_gb": round(memory.total / (1024**3), 1),
        "disk_free_gb": round(disk.free / (1024**3), 1),
        "nvidia_gpus": gpus,
        "apple_silicon": apple_silicon,
        "ffmpeg": ffmpeg_version(),
        "ffmpeg_path": FFMPEG,
    }


def recommended_mode() -> str:
    report = system_report()
    for gpu in report["nvidia_gpus"]:
        if gpu["vram_mb"] >= 7500:
            return "AI Pro (ComfyUI)"
    return "Standard Studio"


def pro_readiness() -> tuple[bool, str]:
    report = system_report()
    if report["nvidia_gpus"]:
        best = max(g["vram_mb"] for g in report["nvidia_gpus"])
        if best >= 7500:
            return True, f"NVIDIA GPU with {best/1024:.1f} GB VRAM detected. AI Pro is suitable."
        return False, f"NVIDIA GPU detected but only {best/1024:.1f} GB VRAM. 8 GB or more is recommended."
    if report["apple_silicon"]:
        return False, "Apple Silicon detected. AI Pro video models are experimental on macOS; use Standard Studio."
    return False, "No NVIDIA GPU detected. Standard Studio will run on CPU; AI Pro needs an NVIDIA GPU."
