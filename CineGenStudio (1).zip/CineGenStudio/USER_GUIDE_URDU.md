# CineGen Studio — Roman Urdu User Guide

Ye aap ka **personal, free aur lifetime AI video tool** hai. Isay aap apne laptop par chalaa sakte hain. Is mein koi subscription, paid API ya login nahi hai.

## 1. Tool kya karta hai?

- Aap character ki image(s) dete hain.
- Aap script likhte hain.
- Tool local AI voice se voiceover banata hai.
- Image par cinematic motion ya AI animation lagti hai.
- **Lip Sync Avatar** mode mein voiceover ke sath character ka munh bhi hilta hai — CPU par, baghair GPU ke.
- **Optional voice cloning** mein aap 5–10 second ki voice sample de kar apni pasand ki aawaz mein script bolwa sakte hain.
- Subtitles, background music aur HD MP4 export hota hai.

## 2. Pehli dafa setup

### Windows

1. Python 3.11 install karein. Install ke waqt **Add Python to PATH** tick karein.
2. `cinegen_studio` folder extract karein.
3. `setup_windows.bat` par double-click karein.
4. Setup complete hone ke baad `start_windows.bat` par double-click karein.
5. Browser mein local page khul jayega — usually `http://127.0.0.1:7860`.

### Mac / Linux

```bash
cd cinegen_studio
chmod +x setup_mac_linux.sh start_mac_linux.command start.sh
./setup_mac_linux.sh
./start_mac_linux.command
```

## 3. Pehli video banayein

### Sab se asaan: Chat Studio tab 💬

1. Right side apni character image upload karein (ya demo character se shuru karein).
2. Chat mein apni script likh kar **Enter** dabayein — har message aik animated section ban jata hai.
3. Jab dil chahaye, aur messages bhejein — bari bari sections banti rahengi, isi character ke sath.
4. **🎬 Combine all sections** dabayein — final video neeche preview aur download ho jayega.

### Full control: Create Video tab 🎬

1. **Create Video** tab kholein.
2. **Load English demo** ya **Load Urdu demo** button dabayein — ye sample image aur script auto load kar dega.
3. Apni image upload karein aur script likhein.
4. **Language** select karein, phir **Voice model** choose karein.
   - `↓` ka matlab: voice pehli dafa download hogi.
   - `✓` ka matlab: voice aap ke laptop par already installed hai.
5. **Animation engine** mein se choose karein:
   - **Standard Studio:** har laptop par chalega, GPU zaroori nahi.
   - **AI Pro (ComfyUI):** advanced AI motion, NVIDIA GPU ke sath.
6. Resolution, motion style aur music select karein.
   - **Lip Sync Avatar** choose karein to voiceover ke sath munh bhi hilega. Ye CPU par chalta hai.
7. **Generate HD Video** dabayein.
8. Video ready hone par MP4, SRT subtitles aur project ZIP download karein.

## 3.1 Voice cloning (optional)

Agar aap chahte hain ke script aap ki apni ya kisi reference voice mein bole:

1. Pehle ek dafa install karein:
   ```bash
   python install.py --voice-clone
   ```
   Ye ~1–2 GB model download karega. Python 3.11 recommended hai.
2. Upar **Voice cloning** accordion kholein.
3. **Voice Clone (Chatterbox)** select karein.
4. Saaf 5–10 second ki voice sample upload karein.
5. Clone language aur device choose karein, phir normal tarike se video generate karein.

Agar ye dependency install na ho to bhi Piper voices, lip-sync aur baqi sab features chalte rahenge.

## 4. Urdu voiceover

- Language mein **Urdu (Pakistan)** select karein.
- Voice `ur_PK-fasih-medium` ya `ur_PK-aegis_female-medium` choose karein.
- Script Urdu mein likhein, masalan:

```text
خوش آمدید۔ یہ آپ کا اپنا مقامی اے آئی ویڈیو اسٹوڈیو ہے۔
کردار کی تصویر اپ لوڈ کریں، اسکرپٹ لکھیں اور خوبصورت ایچ ڈی ویڈیو تیار کریں۔
```

Tool Urdu subtitles ke liye Noto Naskh Arabic font aur RTL shaping use karta hai.

## 5. Multiple languages

Voice Models tab mein 40+ zubanon ke local voice models hain. Chunnda zubanein:

- English (US / UK)
- Urdu
- Hindi
- Arabic
- Spanish
- French
- German
- Turkish
- Persian
- Russian
- Japanese
- Korean
- Chinese
- Bengali
- Portuguese
- Italian
- Dutch
- Polish

Har voice ka apna MODEL_CARD aur license hota hai. Commercial use se pehle us voice ka model card zaroor check karein.

## 6. AI Pro — high-class AI animation

Agar aap ke laptop mein NVIDIA GPU hai (8 GB+ VRAM recommended), to ye mode zyada advanced animation deta hai.

1. ComfyUI install aur start karein.
2. **Global / AI Pro settings** kholein.
   - ComfyUI URL: `http://127.0.0.1:8188`
   - ComfyUI folder path: aap ke ComfyUI folder ka full path.
3. **AI Pro Setup** tab mein **Test ComfyUI connection** dabayein.
4. **Download Wan2.2 Pro models** dabayein. Ye ~17 GB download hai.
5. Jab teenon files **Ready** ho jayein, Create Video mein **AI Pro (ComfyUI)** select karein.

AI Pro slow hota hai aur har scene ke liye aik clip generate karta hai. Behtar results ke liye 2–3 images aur chhota script use karein.

## 7. Free lifetime ka matlab

- App aap ke laptop par local chalta hai.
- Voice aur video models aap ki apni disk par save hote hain.
- Internet sirf pehli dafa model download ke liye chahiye.
- Uske baad voiceover aur video generation offline ho sakti hai.
- Koi monthly fee, API cost ya cloud account nahi.
- Bijli, storage aur hardware aap ke apne hain.

## 8. Common maslay

**Voice download nahi ho raha:** Internet check karein, `models/voices/` mein corrupt `.part` file delete kar ke dobara try karein.

**Urdu subtitles theek nahi dikhte:** `python install.py --fonts-only` chalayein. Fonts `assets/fonts/` mein hone chahiye.

**ComfyUI connect nahi ho raha:** Pehle ComfyUI start karein, phir app mein URL test karein.

**AI Pro bohat slow hai:** Kam images use karein, steps 10–15 karein, ya Standard Studio use karein.

**App start nahi ho raha:** `python install.py --check` chalayein aur missing packages install karein.

## 9. Important notes

- Standard Studio high-quality motion graphics banata hai; ye true lipsync nahi karta.
- AI Pro character motion generate karta hai, lekin voiceover alag se local TTS se aati hai.
- Full commercial use ke liye character image, music, script aur selected voice model ke licenses check karna zaroori hai.
- Zyada details ke liye `README.md` aur `THIRD_PARTY_NOTICES.md` dekhein.
