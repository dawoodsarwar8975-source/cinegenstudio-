from __future__ import annotations

import argparse
import json
import random
import shutil
import uuid
import zipfile
from datetime import datetime
from pathlib import Path

from cinegen.comfy import ComfyClient
from cinegen.config import DEFAULT_SETTINGS, OUTPUT_DIR, WORK_DIR
from cinegen.imaging import prepare_ai_input, prepare_scene_assets
from cinegen.lipsync import render_lipsync_scene
from cinegen.tts import partition_sentences, split_script, synthesize_scenes
from cinegen.video import (
    RESOLUTIONS,
    concat_scenes,
    loop_trim_clip,
    mux_final,
    render_standard_scene,
)


def ai_native_resolution(width: int, height: int) -> tuple[int, int]:
    ratio = width / height
    if ratio >= 1.4:
        return 1280, 704
    if ratio <= 0.75:
        return 704, 1280
    return 960, 960


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate a CineGen Studio video from the command line")
    parser.add_argument("--image", action="append", required=True, help="Character image path; repeat for multiple scenes")
    parser.add_argument("--script", help="Voiceover script text")
    parser.add_argument("--script-file", help="Path to a UTF-8 text file containing the script")
    parser.add_argument("--language", default="en_US", help="Language code, e.g. en_US, ur_PK, hi_IN")
    parser.add_argument("--voice", help="Piper voice key; defaults to a recommended voice for the language")
    parser.add_argument("--voice-engine", choices=["piper", "clone"], default="piper")
    parser.add_argument("--reference-audio", help="5–10 second voice sample for Chatterbox cloning")
    parser.add_argument("--clone-language", default="en", help="Chatterbox language id, e.g. en, ur, hi, ar")
    parser.add_argument("--clone-device", choices=["auto", "cpu", "cuda", "mps"], default="auto")
    parser.add_argument("--mode", choices=["standard", "pro"], default="standard")
    parser.add_argument("--resolution", choices=list(RESOLUTIONS.keys()), default="1080p")
    parser.add_argument(
        "--style",
        choices=["Standard Studio", "Cinematic Zoom", "Gentle Parallax", "Dynamic", "Lip Sync Avatar"],
        default="Standard Studio",
    )
    parser.add_argument("--speed", type=float, default=1.0)
    parser.add_argument("--motion", type=float, default=0.5)
    parser.add_argument("--music", help="Optional background music file")
    parser.add_argument("--music-volume", type=float, default=0.15)
    parser.add_argument("--no-subtitles", action="store_true")
    parser.add_argument("--comfy-url", default=DEFAULT_SETTINGS["comfy_url"])
    parser.add_argument("--ai-steps", type=int, default=20)
    parser.add_argument("--output", help="Output MP4 path")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.script_file:
        script = Path(args.script_file).read_text(encoding="utf-8")
    elif args.script:
        script = args.script
    else:
        raise SystemExit("Provide --script or --script-file.")

    from cinegen.catalog import recommended_voice

    voice = args.voice or recommended_voice(args.language)
    if args.voice_engine == "clone":
        if not args.reference_audio or not Path(args.reference_audio).exists():
            raise SystemExit("--reference-audio is required for --voice-engine clone.")
        voice = f"chatterbox-clone:{args.clone_language}"
    elif not voice:
        raise SystemExit(f"No Piper voice found for language {args.language}.")

    images = [Path(p).expanduser().resolve() for p in args.image]
    for image in images:
        if not image.exists():
            raise SystemExit(f"Image not found: {image}")
    if args.mode == "pro" and len(images) > 12:
        images = images[:12]

    width, height = RESOLUTIONS[args.resolution]
    job_id = datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:6]
    job_dir = WORK_DIR / f"cli_{job_id}"
    scene_dir = job_dir / "scenes"
    ai_dir = job_dir / "ai_clips"
    for folder in (job_dir, scene_dir, ai_dir):
        folder.mkdir(parents=True, exist_ok=True)

    sentences = split_script(script)
    groups = partition_sentences(sentences, len(images))
    print(f"Synthesizing {len(sentences)} sentences across {len(groups)} scene(s) with {voice}…")
    tts = synthesize_scenes(
        groups=groups,
        voice_key=voice,
        output_dir=job_dir / "audio",
        speech_rate=args.speed,
        resolution=(width, height),
        voice_engine=args.voice_engine,
        reference_audio=Path(args.reference_audio) if args.reference_audio else None,
        clone_language_id=args.clone_language,
        clone_device=args.clone_device,
        progress=lambda fraction, message: print(f"  [{int(fraction*100):3d}%] {message}"),
    )
    scenes = tts["scenes"]
    scene_videos = []

    if args.mode == "pro":
        client = ComfyClient(args.comfy_url)
        try:
            client.system_stats()
        except Exception as exc:
            raise SystemExit(f"Cannot reach ComfyUI at {args.comfy_url}: {exc}") from exc
        native_w, native_h = ai_native_resolution(width, height)
        positive = DEFAULT_SETTINGS["last_motion_prompt"] + " Visual story context: " + " ".join(sentences)[:380]
        negative = DEFAULT_SETTINGS["last_negative_prompt"]
        for index, (scene, image) in enumerate(zip(scenes, images)):
            print(f"Generating AI Pro scene {index + 1}/{len(scenes)}…")
            ai_input = prepare_ai_input(image, job_dir / f"ai_input_{index:03d}.jpg", native_w, native_h)
            config = {
                "positive_prompt": positive,
                "negative_prompt": negative,
                "width": native_w,
                "height": native_h,
                "length": max(25, min(121, int(scene["duration"] * 24))),
                "fps": 24,
                "seed": random.randint(1, 2**31 - 1),
                "steps": args.ai_steps,
                "cfg": 5.0,
                "filename_prefix": f"CineGenCLI/{job_id}_{index:03d}",
                "shift": 8.0,
            }
            clip = client.generate_clip(ai_input, config, ai_dir, progress=lambda f, m: print(f"  {m}"))
            scene_video = scene_dir / f"ai_{index:03d}.mp4"
            loop_trim_clip(clip, scene_video, scene["duration"], width, height)
            scene_videos.append(scene_video)
    else:
        for index, (scene, image) in enumerate(zip(scenes, images)):
            print(f"Rendering standard scene {index + 1}/{len(scenes)}…")
            bg, fg = prepare_scene_assets(image, job_dir / f"assets_{index:03d}", width, height)
            scene["background"] = bg
            scene["foreground"] = fg
            scene["image_path"] = image
            scene_video = scene_dir / f"standard_{index:03d}.mp4"
            if args.style == "Lip Sync Avatar":
                render_lipsync_scene(
                    scene,
                    scene_video,
                    width,
                    height,
                    intensity=args.motion,
                    progress=lambda f, m: print(f"  {m}"),
                )
            else:
                render_standard_scene(
                    scene,
                    scene_video,
                    width,
                    height,
                    style=args.style,
                    intensity=args.motion,
                    progress=lambda f, m: print(f"  {m}"),
                )
            scene_videos.append(scene_video)

    print("Compositing final video…")
    silent = concat_scenes(scene_videos, job_dir / "silent.mp4")
    output = Path(args.output).expanduser().resolve() if args.output else OUTPUT_DIR / f"CineGen_CLI_{job_id}.mp4"
    output.parent.mkdir(parents=True, exist_ok=True)
    music = Path(args.music).expanduser().resolve() if args.music else None
    mux_final(
        silent_video=silent,
        voice_wav=tts["full_voice_wav"],
        output_path=output,
        duration=tts["total_duration"],
        width=width,
        height=height,
        music_path=music,
        music_volume=args.music_volume,
        subtitle_path=None if args.no_subtitles else tts["ass_path"],
    )
    metadata = {
        "created": datetime.now().isoformat(timespec="seconds"),
        "mode": args.mode,
        "voice": voice,
        "voice_engine": args.voice_engine,
        "language": tts.get("language", args.language),
        "resolution": [width, height],
        "duration_seconds": tts["total_duration"],
        "script": script,
        "images": [str(p) for p in images],
    }
    (output.parent / f"{output.stem}_settings.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"\nDone: {output}")
    print(f"Subtitles: {tts['srt_path']}")


if __name__ == "__main__":
    main()
