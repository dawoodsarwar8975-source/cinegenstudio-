#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "================================================"
echo "  CineGen Studio - macOS/Linux one-time setup"
echo "================================================"
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python install.py --fonts-only
chmod +x start_mac_linux.command start.sh 2>/dev/null || true
echo
echo "Setup complete. Use ./start_mac_linux.command or ./start.sh to launch."
