from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from cinegen.catalog import CATALOG, language_choices, recommended_voice, voice_choices
from cinegen.config import DEFAULT_WORKFLOW_PATH
from cinegen.imaging import compose_scene_frame, make_placeholder_character, prepare_scene_assets
from cinegen.lipsync import audio_envelope, detect_mouth_bbox
from cinegen.subtitles import font_for_language, format_timestamp, global_segments, write_srt
from cinegen.tts import partition_sentences, split_script
from cinegen.video import RESOLUTIONS
from cinegen.voice_clone import VOICE_CLONE_LANGUAGES, availability, locale_to_clone_language
from cinegen.workflow import adjust_frame_length, ui_to_api


class CoreTests(unittest.TestCase):
    def test_catalog_has_multiple_languages(self):
        self.assertGreater(len(language_choices()), 20)
        self.assertIn("ur_PK", [code for _, code in language_choices()])
        self.assertTrue(recommended_voice("en_US"))
        self.assertTrue(voice_choices("ur_PK"))

    def test_script_split_supports_urdu_and_english(self):
        english = split_script("Hello there. This is a test! Is it working?")
        urdu = split_script("یہ ایک ٹیسٹ ہے۔ کیا یہ کام کر رہا ہے؟")
        self.assertEqual(len(english), 3)
        self.assertEqual(len(urdu), 2)

    def test_partition_sentences(self):
        sentences = [f"Sentence {i}." for i in range(10)]
        groups = partition_sentences(sentences, 3)
        self.assertEqual(len(groups), 3)
        self.assertEqual(sum(len(group) for group in groups), 10)
        self.assertTrue(all(len(group) >= 1 for group in groups))

    def test_srt_and_global_timings(self):
        scenes = [
            {
                "duration": 5.0,
                "subtitle_segments": [{"start": 0.5, "end": 2.0, "text": "First line"}],
            },
            {
                "duration": 4.0,
                "subtitle_segments": [{"start": 0.4, "end": 1.8, "text": "دوسری لائن"}],
            },
        ]
        segments = global_segments(scenes)
        self.assertAlmostEqual(segments[0]["start"], 0.5)
        self.assertAlmostEqual(segments[1]["start"], 5.4)
        self.assertEqual(format_timestamp(1.234), "00:00:01,234")
        with tempfile.TemporaryDirectory() as tmp:
            path = write_srt(segments, Path(tmp) / "test.srt", language="ur_PK")
            text = path.read_text(encoding="utf-8")
            self.assertIn("00:00:05,400", text)
            self.assertIn("دوسری", text)

    def test_font_selection(self):
        self.assertEqual(font_for_language("ur_PK", "یہ اردو ہے")[1], "Noto Naskh Arabic")
        self.assertEqual(font_for_language("hi_IN", "यह हिंदी है")[1], "Noto Sans Devanagari")
        self.assertEqual(font_for_language("ja_JP", "これは日本語です")[1], "Noto Sans CJK SC")
        self.assertEqual(font_for_language("en_US", "Hello")[1], "Noto Sans")

    def test_workflow_conversion(self):
        with DEFAULT_WORKFLOW_PATH.open("r", encoding="utf-8") as handle:
            ui_workflow = json.load(handle)
        api = ui_to_api(ui_workflow)
        class_types = {node["class_type"] for node in api.values()}
        self.assertIn("UNETLoader", class_types)
        self.assertIn("Wan22ImageToVideoLatent", class_types)
        self.assertIn("SaveVideo", class_types)
        loaders = [node for node in api.values() if node["class_type"] == "LoadImage"]
        self.assertIn("image", loaders[0]["inputs"])
        self.assertNotIn("upload", loaders[0]["inputs"])
        samplers = [node for node in api.values() if node["class_type"] == "KSampler"]
        self.assertIn("seed", samplers[0]["inputs"])
        self.assertNotIn("control_after_generate", samplers[0]["inputs"])

    def test_frame_length_step(self):
        self.assertEqual(adjust_frame_length(1), 25)
        self.assertEqual(adjust_frame_length(121), 121)
        self.assertEqual((adjust_frame_length(73) - 1) % 4, 0)

    def test_resolution_map(self):
        self.assertEqual(RESOLUTIONS["1080p"], (1920, 1080))
        self.assertEqual(RESOLUTIONS["Vertical 1080x1920"], (1080, 1920))

    def test_scene_asset_generation(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            image = make_placeholder_character(root / "character.png", size=256)
            bg, fg = prepare_scene_assets(image, root / "assets", 640, 360)
            self.assertTrue(bg.exists())
            self.assertTrue(fg.exists())
            from PIL import Image

            with Image.open(bg) as bg_image, Image.open(fg) as fg_image:
                self.assertEqual(bg_image.size, (640, 360))
                self.assertEqual(fg_image.size, (640, 360))
                self.assertEqual(fg_image.mode, "RGBA")

    def test_compose_scene_frame(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            image = make_placeholder_character(root / "character.png", size=256)
            frame, foreground, placement = compose_scene_frame(image, 640, 360)
            self.assertEqual(frame.size, (640, 360))
            self.assertEqual(frame.mode, "RGB")
            self.assertGreater(foreground.width, 0)
            self.assertEqual(len(placement), 2)

    def test_audio_envelope(self):
        import math
        import wave

        import numpy as np

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "tone.wav"
            sample_rate = 22050
            t = np.linspace(0, 1.0, sample_rate, endpoint=False)
            samples = (np.sin(2 * math.pi * 220 * t) * 12000).astype("<i2")
            with wave.open(str(path), "wb") as handle:
                handle.setnchannels(1)
                handle.setsampwidth(2)
                handle.setframerate(sample_rate)
                handle.writeframes(samples.tobytes())
            envelope = audio_envelope(path, fps=30, duration=1.0)
            self.assertEqual(len(envelope), 30)
            self.assertGreaterEqual(float(envelope.min()), 0.0)
            self.assertLessEqual(float(envelope.max()), 1.0)
            self.assertGreater(float(envelope.mean()), 0.1)

    def test_voice_clone_language_mapping(self):
        self.assertEqual(locale_to_clone_language("ur_PK"), "ur")
        self.assertEqual(locale_to_clone_language("hi_IN"), "hi")
        self.assertEqual(locale_to_clone_language("en_US"), "en")
        self.assertIn(locale_to_clone_language("xx_XX"), VOICE_CLONE_LANGUAGES)

    def test_voice_clone_availability_shape(self):
        info = availability()
        self.assertIn("available", info)
        self.assertIn("device", info)
        self.assertIsInstance(info["available"], bool)

    def test_mouth_detection_returns_usable_box(self):
        from cinegen.config import ASSETS_DIR

        image = ASSETS_DIR / "sample_character.png"
        if not image.exists():
            self.skipTest("Sample character image is not available.")
        x, y, w, h = detect_mouth_bbox(image)
        self.assertGreater(w, 10)
        self.assertGreater(h, 8)
        self.assertGreaterEqual(x, 0)
        self.assertGreaterEqual(y, 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
