# Changelog

## v2.1 — Chat Studio

### Added

- **Chat Studio tab (first tab)** — a simple chat interface:
  - Type a script message → it becomes one animated video section with your character.
  - Sections build up one by one in the same chat ("bari bari"), in any order you like.
  - Each section renders immediately with voiceover and subtitles, playable inside the chat.
  - **Combine all sections → Final video** joins everything into one MP4 with global timed subtitles and optional background music.
  - **New project** button starts a fresh chat; old sections stay on disk.
  - Character images cycle automatically across sections; the bundled demo character is used when none is uploaded.
  - All chat styles available, including **Lip Sync Avatar** (default) and the cinematic motion styles.
- New `cinegen/chat_studio.py` module (`new_project`, `generate_section`, `combine_sections`).
- Sections can use different resolutions/styles; combine normalizes them automatically.

## v2.0 — CPU lip-sync + optional voice cloning

### Added

- **Lip Sync Avatar** animation style. OpenCV detects the character's face/mouth, a smoothed audio envelope drives 9 mouth-openness variants, and frames are rendered at 30 fps on CPU. No neural lip-sync model or GPU is required.
- **Voice Cloning (Chatterbox)** optional engine. Upload a clean 5–10 second reference voice sample and generate the voiceover in that voice across 23+ languages. MIT-licensed model; installed separately via `requirements-voice-cloning.txt` or `python install.py --voice-clone`.
- New `cinegen/lipsync.py`, `cinegen/voice_clone.py`, mouth Haar cascade in `assets/`, and `compose_scene_frame()` helper.
- CLI flags: `--voice-engine`, `--reference-audio`, `--clone-language`, `--clone-device`, and `Lip Sync Avatar` style.
- Web UI voice-engine controls in a collapsible **Voice cloning** accordion, with dependency status and install command.
- New demo: `examples/demo_lipsync_720p.mp4`.
- 14 automated tests covering audio envelope, mouth detection, scene composition, voice-clone mapping, workflow conversion, subtitles and catalog.

### Fixed

- Mouth detection now prefers the real mouth in the lower face instead of the nose/chin.
- Lip-sync mouth rendering preserves the character's original skin/lip hue instead of painting a coloured overlay.
- Concat demuxer uses absolute paths, fixing multi-scene joins when work directories are nested.
- SRT files keep editable Unicode; RTL shaping is applied only to burned-in ASS subtitles.

## v1 — initial local AI video studio

- Gradio web dashboard and CLI.
- Piper local multilingual TTS with 178 voices / 40+ locales.
- Standard Studio cinematic motion, subtitles, background music and HD/4K export.
- Optional Wan2.2 AI Pro via ComfyUI local API.
- Bundled Noto fonts, official Wan2.2 workflow, installers and documentation.
