@echo off
setlocal
cd /d "%~dp0"
echo ================================================
echo   CineGen Studio - Windows one-time setup
echo ================================================
where py >nul 2>nul
if %errorlevel%==0 (
    set PYCMD=py -3
) else (
    set PYCMD=python
)
echo Using Python launcher: %PYCMD%
%PYCMD% -m venv .venv
if errorlevel 1 goto :error
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 goto :error
python install.py --fonts-only
if errorlevel 1 goto :error
echo.
echo Setup complete. Use start_windows.bat to launch CineGen Studio.
pause
exit /b 0
:error
echo.
echo Setup failed. Please read the error above.
pause
exit /b 1
