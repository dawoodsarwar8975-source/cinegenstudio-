from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

import requests

FONT_URLS = {
    "NotoSans.ttf": "https://raw.githubusercontent.com/google/fonts/main/ofl/notosans/NotoSans%5Bwdth,wght%5D.ttf",
    "NotoNaskhArabic.ttf": "https://raw.githubusercontent.com/google/fonts/main/ofl/notonaskharabic/NotoNaskhArabic%5Bwght%5D.ttf",
    "NotoSansDevanagari.ttf": "https://raw.githubusercontent.com/google/fonts/main/ofl/notosansdevanagari/NotoSansDevanagari%5Bwdth,wght%5D.ttf",
    "NotoSansCJKsc.otf": "https://raw.githubusercontent.com/notofonts/noto-cjk/main/Sans/OTF/SimplifiedChinese/NotoSansCJKsc-Regular.otf",
    "OFL-LICENSE.txt": "https://raw.githubusercontent.com/google/fonts/main/ofl/notosans/OFL.txt",
}

WORKFLOW_URL = "https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/templates/video_wan2_2_5B_ti2v.json"
CATALOG_URL = "https://huggingface.co/rhasspy/piper-voices/resolve/main/voices.json"
MOUTH_CASCADE_URL = "https://raw.githubusercontent.com/atduskgreg/opencv-processing/master/lib/cascade-files/haarcascade_mcs_mouth.xml"


def project_root() -> Path:
    return Path(__file__).resolve().parent


def download(url: str, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    response = requests.get(url, timeout=180)
    response.raise_for_status()
    target.write_bytes(response.content)
    print(f"  downloaded {target.relative_to(project_root())} ({len(response.content):,} bytes)")


def ensure_fonts() -> None:
    print("Checking multilingual fonts…")
    fonts = project_root() / "assets" / "fonts"
    for name, url in FONT_URLS.items():
        target = fonts / name
        if target.exists() and target.stat().st_size > 1000:
            continue
        download(url, target)


def ensure_core_data() -> None:
    print("Checking core data files…")
    workflow = project_root() / "workflows" / "wan22_5b_i2v.json"
    if not workflow.exists():
        download(WORKFLOW_URL, workflow)
    mouth_cascade = project_root() / "assets" / "haarcascade_mcs_mouth.xml"
    if not mouth_cascade.exists() or mouth_cascade.stat().st_size < 100_000:
        download(MOUTH_CASCADE_URL, mouth_cascade)
    catalog = project_root() / "data" / "voices_catalog.json"
    if not catalog.exists():
        raw = json.loads(requests.get(CATALOG_URL, timeout=60).content)
        simplified = {}
        for key, value in raw.items():
            simplified[key] = {
                "key": key,
                "name": value.get("name"),
                "language": value.get("language", {}),
                "quality": value.get("quality"),
                "num_speakers": value.get("num_speakers", 1),
                "files": {
                    path: {
                        "size_bytes": meta.get("size_bytes", 0),
                        "md5_digest": meta.get("md5_digest", ""),
                    }
                    for path, meta in value.get("files", {}).items()
                    if path.endswith(".onnx") or path.endswith(".onnx.json") or path.endswith("MODEL_CARD")
                },
            }
        catalog.parent.mkdir(parents=True, exist_ok=True)
        catalog.write_text(json.dumps(simplified, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"  wrote {catalog.relative_to(project_root())} ({len(simplified)} voices)")
    for folder in ("outputs", "work", "models/voices"):
        (project_root() / folder).mkdir(parents=True, exist_ok=True)


def check_dependencies() -> None:
    print("Checking Python dependencies…")
    required = [
        "gradio",
        "PIL",
        "numpy",
        "imageio_ffmpeg",
        "piper",
        "requests",
        "psutil",
        "cv2",
        "arabic_reshaper",
        "bidi",
    ]
    missing = []
    for module in required:
        try:
            __import__(module)
        except Exception as exc:
            missing.append(f"{module} ({exc})")
    if missing:
        print("  Missing or broken:")
        for item in missing:
            print(f"   - {item}")
        print("\nRun: python -m pip install -r requirements.txt")
        raise SystemExit(1)
    print("  All required Python packages are importable.")


def print_system_summary() -> None:
    try:
        from cinegen.hardware import pro_readiness, system_report

        report = system_report()
        ready, note = pro_readiness()
        ffmpeg = report["ffmpeg_path"]
        print("\nSystem summary")
        print(f"  OS: {report['os']} ({report['architecture']})")
        print(f"  Python: {report['python']}")
        print(f"  RAM: {report['ram_gb']} GB, free disk: {report['disk_free_gb']} GB")
        print(f"  FFmpeg: {ffmpeg}")
        print(f"  AI Pro: {'ready' if ready else 'not ready'} — {note}")
    except Exception as exc:
        print(f"  Could not build system summary: {exc}")


def main() -> None:
    parser = argparse.ArgumentParser(description="CineGen Studio setup helper")
    parser.add_argument("--fonts-only", action="store_true", help="Only verify/download fonts and core data")
    parser.add_argument("--check", action="store_true", help="Only check dependencies and system")
    parser.add_argument("--voice", help="Download a specific Piper voice key during setup")
    parser.add_argument("--voice-clone", action="store_true", help="Install optional Chatterbox voice-cloning dependencies")
    args = parser.parse_args()

    root = project_root()
    print(f"CineGen Studio setup — {root}")
    ensure_core_data()
    if args.check:
        check_dependencies()
        print_system_summary()
        return
    ensure_fonts()
    check_dependencies()
    if args.voice_clone:
        print("Installing optional voice-cloning dependencies (this can take several minutes)…")
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "-r", str(project_root() / "requirements-voice-cloning.txt")]
        )
        from cinegen.voice_clone import availability

        print("  Voice cloning availability:", "ready" if availability()["available"] else "not ready")
    if args.voice:
        from cinegen.catalog import ensure_voice

        print(f"Downloading voice model: {args.voice}")
        ensure_voice(args.voice, lambda fraction, message: print(f"  {int(fraction*100)}% {message}"))
    print_system_summary()
    print("\nSetup complete.")
    if not args.fonts_only:
        print("Start the app with: python app.py")


if __name__ == "__main__":
    main()
