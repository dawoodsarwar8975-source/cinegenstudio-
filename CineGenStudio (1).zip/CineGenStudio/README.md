# CineGen Studio

**A free, lifetime, local AI video studio for your laptop.** Give it one or more character images and a script; it creates an HD video with multilingual voiceover, cinematic motion, timed subtitles and optional background music.

> No subscription. No paid API. No cloud account. Models are downloaded once to your own computer and generation then works offline.

---

## What it can do

- ✅ **Chat Studio:** the simplest workflow — type your script in a chat, one message = one animated section with your character, then combine everything into the final video.
- ✅ **Character images → video:** one image per scene; multiple images create a multi-scene video.
- ✅ **Multilingual local voiceover:** 178 Piper voice models across 40+ language locales, including English, Urdu, Hindi, Arabic, Spanish, French, German, Turkish, Persian, Russian, Japanese, Korean, Chinese and more.
- ✅ **HD/4K export:** 720p, 1080p, vertical 1080×1920, square, and 4K UHD.
- ✅ **CPU lip-sync avatar:** audio-driven mouth movement using OpenCV face detection — no neural model, GPU or extra download needed.
- ✅ **Optional true voice cloning:** Chatterbox Multilingual V3 (MIT) can speak your script from a 5–10 second reference voice sample.
- ✅ **Professional finishing:** blurred cinematic background, camera drift, zoom/parallax, grain, vignette, fades, subtitles, music mixing and fast-start MP4.
- ✅ **Urdu/Arabic/Hindi/CJK subtitles:** bundled Noto fonts, RTL shaping and an editable SRT file.
- ✅ **Optional true AI animation:** ComfyUI + Wan2.2 TI2V-5B for image-to-video generation on NVIDIA GPUs.
- ✅ **Easy local dashboard:** browser-based Gradio UI, plus a command-line interface.
- ✅ **Project export:** final MP4, SRT, ASS subtitles, voice WAV and settings in a ZIP.

### Two engines

| Engine | Hardware | What it does | Speed |
|---|---|---|---|
| **Standard Studio** | Any modern laptop, CPU only | Cinematic motion graphics from your character image + local voiceover + subtitles | Fast, usually seconds to a few minutes |
| **AI Pro (ComfyUI)** | NVIDIA GPU, 8 GB+ VRAM recommended | True AI image-to-video motion using Wan2.2 5B, then voiceover/subtitles/music are added | Slow, minutes per scene |

Standard Studio is always available. AI Pro is optional and requires a one-time ~17 GB model download.

---

## Quick start

### Requirements

- Python 3.10–3.13 (3.11 recommended)
- 8 GB RAM minimum; 16 GB recommended
- ~1 GB free disk for the app + ~60–80 MB per downloaded voice
- Optional AI Pro: NVIDIA GPU with 8 GB+ VRAM, ComfyUI installed, ~20 GB free disk

### Windows

1. Install **Python 3.11** from python.org. During installation, check **Add Python to PATH**.
2. Extract this folder.
3. Double-click **`setup_windows.bat`**. Wait for dependencies and fonts to install.
4. Double-click **`start_windows.bat`**.
5. Your browser opens the local dashboard, usually at `http://127.0.0.1:7860`.

### macOS / Linux

```bash
cd cinegen_studio
chmod +x setup_mac_linux.sh start_mac_linux.command start.sh
./setup_mac_linux.sh
./start_mac_linux.command
```

Or manually:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python install.py --fonts-only
python app.py
```

---

## First video in 60 seconds

The fastest way is the **💬 Chat Studio** tab:

1. Upload your character image on the right (or start with the demo character).
2. Type your script in the chat and press **Enter** — each message becomes one animated section.
3. Send more messages for more sections, in any order you like.
4. Press **🎬 Combine all sections → Final video** and download the result.

The **🎬 Create Video** tab is the full form-based workflow:

1. Open the **Create Video** tab.
2. Click **Load English demo** or **Load Urdu demo** to try it instantly.
3. Or upload your own character image(s) and paste your script.
4. Choose **Language** and **Voice model**. A voice marked `↓` downloads automatically the first time.
5. Choose **Standard Studio** for CPU, or **AI Pro** after ComfyUI setup.
6. Select resolution, motion style and music.
7. Click **Generate HD Video**.
8. Preview and download the MP4, SRT subtitles or complete project ZIP.

All outputs are saved in `outputs/`. Intermediate files are in `work/`.

### Lip Sync Avatar mode

Select **Lip Sync Avatar** as the motion style to make the character's mouth move with the voiceover on a normal CPU laptop.

How it works:

1. OpenCV detects the face and mouth in your character image.
2. The app computes a smoothed loudness envelope from the generated WAV.
3. It renders 9 mouth-openness variants and blends them frame by frame at 30 fps.
4. The rest of the face keeps the cinematic background, soft edges, subtitles and audio pipeline.

It is a fast, private, offline talking-head effect — not a diffusion model. For full head/body motion use AI Pro. If automatic mouth detection is wrong for a highly stylized character, use a clearer front-facing portrait.

Lip-sync command-line example:

```bash
python cli.py --image assets/sample_character.png --script "Hello, this is a lip sync test." --language en_US --voice en_US-amy-medium --style "Lip Sync Avatar" --resolution 720p
```

### Optional voice cloning

CineGen Studio also supports true zero-shot voice cloning through **Chatterbox Multilingual V3**, an MIT-licensed local model [2](https://pypi.org/project/chatterbox-tts/). It is not installed by default because it pulls PyTorch and about 1–2 GB of model weights.

Install once:

```bash
python install.py --voice-clone
# or
python -m pip install -r requirements-voice-cloning.txt
```

Python 3.11 is recommended. Then:

1. Open the **Voice cloning** accordion above the tabs.
2. Select **Voice Clone (Chatterbox)**.
3. Upload a clean 5–10 second reference voice sample.
4. Choose the clone language and device.
5. Generate the video as usual.

If the optional package is missing, the app shows a clear install command and all Piper voices keep working. Voice cloning uses the reference speaker's voice; you must have permission to clone that voice.

Voice-cloning command-line example:

```bash
python cli.py --image assets/sample_character.png --script "Hello in my own voice." --language en_US --voice-engine clone --reference-audio my_voice.wav --clone-language en --resolution 720p
```

---

## AI Pro setup

1. Install and start [ComfyUI](https://github.com/Comfy-Org/ComfyUI) on the same laptop.
2. Open **Global / AI Pro settings** in CineGen Studio:
   - **ComfyUI server URL:** usually `http://127.0.0.1:8188`
   - **ComfyUI folder path:** the full path to your ComfyUI folder, e.g. `C:\AI\ComfyUI`
3. Open **AI Pro Setup** → **Test ComfyUI connection**.
4. Click **Download Wan2.2 Pro models**. This downloads three files (~17 GB):
   - `wan2.2_ti2v_5B_fp16.safetensors` (~9.31 GB)
   - `wan2.2_vae.safetensors` (~1.31 GB)
   - `umt5_xxl_fp8_e4m3fn_scaled.safetensors` (~6.27 GB)
5. When all three show **Ready**, choose **AI Pro (ComfyUI)** in Create Video.

The official ComfyUI Wan2.2 guide states that the 5B model should fit on about 8 GB VRAM with native offloading. Native AI clips are approximately 720p; CineGen Studio upscales them to your chosen output resolution. Long scripts are split into scenes, with one AI clip generated per character image.

**Tip:** For faster results, start with 2–3 images, 1080p output and 20 sampling steps.

---

## Voice models

Open **Voice Models** to download, verify or remove voices.

- `✓` means installed locally.
- `↓` means it will download on first use (about 60–80 MB).
- Each voice has a model-card link. Voice datasets have separate licenses; check them before commercial distribution.
- Urdu voices are available as `ur_PK-fasih-medium` and `ur_PK-aegis_female-medium`.

Voice files are stored in `models/voices/` and can be backed up like any other folder.

---

## Command-line usage

```bash
python cli.py \
  --image assets/sample_character.png \
  --script "Welcome to CineGen Studio. This video was made locally, for free." \
  --language en_US \
  --voice en_US-amy-medium \
  --resolution 1080p \
  --style "Cinematic Zoom" \
  --output outputs/my_first_video.mp4
```

Urdu example:

```bash
python cli.py \
  --image assets/sample_character.png \
  --script-file my_urdu_script.txt \
  --language ur_PK \
  --voice ur_PK-fasih-medium \
  --resolution 1080p
```

AI Pro example:

```bash
python cli.py \
  --image character1.png --image character2.png \
  --script-file script.txt \
  --language en_US \
  --mode pro \
  --comfy-url http://127.0.0.1:8188
```

---

## Folder structure

```text
cinegen_studio/
├── app.py                     # Gradio web dashboard
├── cli.py                     # Command-line generator
├── install.py                 # Setup / dependency verification
├── requirements.txt
├── cinegen/                   # Core modules
│   ├── catalog.py             # Piper voice catalog and downloads
│   ├── tts.py                 # Local multilingual voice synthesis
│   ├── subtitles.py           # SRT/ASS, RTL and font handling
│   ├── imaging.py             # Cinematic backgrounds / AI input frames
│   ├── video.py               # FFmpeg rendering and muxing
│   ├── comfy.py               # ComfyUI local API client
│   ├── workflow.py            # Wan2.2 UI workflow → API prompt
│   ├── pro_models.py          # 17 GB model installer
│   └── hardware.py            # GPU/RAM/FFmpeg detection
├── assets/fonts/              # Bundled Noto fonts
├── data/                      # Voice catalog and Pro model URLs
├── workflows/                 # Official Wan2.2 5B workflow
├── models/voices/             # Downloaded local voices
├── outputs/                   # Final MP4 and project ZIPs
└── work/                      # Intermediate render files
```

---

## Troubleshooting

**App does not start**
- Confirm Python is installed: `python --version` or `python3 --version`.
- Re-run `setup_windows.bat` / `setup_mac_linux.sh`.
- Check dependencies: `python install.py --check`.

**Voice download fails**
- First download needs internet. Check your connection and free disk space.
- Try another voice in the same language from **Voice Models**.
- If a `.part` file is corrupt, delete it from `models/voices/` and retry.

**Subtitles show boxes or wrong characters**
- Confirm the bundled fonts exist in `assets/fonts/`.
- Run `python install.py --fonts-only`.
- For right-to-left languages, keep the Urdu/Arabic voice and script together.

**AI Pro cannot connect**
- Start ComfyUI first. Its default URL is `http://127.0.0.1:8188`.
- If ComfyUI runs on another port, update **Global / AI Pro settings**.
- Use **AI Pro Setup → Test ComfyUI connection**.

**AI Pro is very slow or runs out of VRAM**
- Use fewer character images and shorter scenes.
- Use 720p or 1080p output rather than 4K.
- Lower AI Pro sampling steps to 10–15.
- Use Standard Studio on laptops without a suitable NVIDIA GPU.

**FFmpeg error**
- The app uses `imageio-ffmpeg`, which includes a static binary. Reinstall it:
  ```bash
  python -m pip install --upgrade imageio-ffmpeg
  ```

---

## Privacy and “free lifetime”

- Your scripts, images and generated media stay in this folder on your laptop.
- Voice models and optional Wan2.2 models are downloaded from public repositories once.
- No telemetry, no login, no API key and no recurring payment are included.
- You still need electricity, storage and compatible hardware.
- Third-party model licenses can change; keep local backups and review upstream notices.

See **THIRD_PARTY_NOTICES.md** for licenses and **USER_GUIDE_URDU.md** for Roman Urdu instructions.

---

## References

- ComfyUI Wan2.2 official workflow: https://docs.comfy.org/tutorials/video/wan/wan2_2
- Wan2.2 5B model card: https://huggingface.co/Wan-AI/Wan2.2-TI2V-5B
- ComfyUI server API examples: https://docs.comfy.org/development/comfyui-server/api-examples
- Piper TTS Python API: https://github.com/OHF-Voice/piper1-gpl/blob/main/docs/API_PYTHON.md
- Piper voice catalog: https://huggingface.co/rhasspy/piper-voices
- Chatterbox Multilingual V3 voice cloning: https://github.com/resemble-ai/chatterbox
- Official workflow template: https://github.com/Comfy-Org/workflow_templates/blob/main/templates/video_wan2_2_5B_ti2v.json
