from __future__ import annotations

import argparse
import html
import json
import random
import re
import shutil
import traceback
import uuid
import zipfile
from datetime import datetime
from pathlib import Path

import gradio as gr

from cinegen import __version__
from cinegen.chat_studio import CHAT_STYLES, combine_sections, generate_section, new_project
from cinegen.catalog import (
    delete_voice,
    ensure_voice,
    installed_voices,
    is_voice_installed,
    language_choices,
    model_card_url,
    recommended_voice,
    voice_choices,
)
from cinegen.comfy import ComfyClient
from cinegen.config import (
    ASSETS_DIR,
    DEFAULT_SETTINGS,
    OUTPUT_DIR,
    ROOT,
    WORK_DIR,
    load_settings,
    save_settings,
)
from cinegen.hardware import comfy_status, pro_readiness, system_report
from cinegen.imaging import make_placeholder_character, prepare_ai_input, prepare_scene_assets
from cinegen.pro_models import check_pro_models, install_pro_models
from cinegen.tts import partition_sentences, split_script, synthesize_scenes
from cinegen.voice_clone import (
    VOICE_CLONE_LANGUAGES,
    availability,
    install_instructions,
)
from cinegen.lipsync import render_lipsync_scene
from cinegen.video import (
    RESOLUTIONS,
    concat_scenes,
    loop_trim_clip,
    mux_final,
    render_standard_scene,
)

SAMPLE_IMAGE = ASSETS_DIR / "sample_character.png"

DEMO_SCRIPTS = {
    "en_US": (
        "Welcome to CineGen Studio. This is your own private AI video tool. "
        "Upload a character image, write your script, choose a voice, and export a polished HD video. "
        "Everything runs locally on your laptop, with no subscription and no paid API."
    ),
    "ur_PK": (
        "خوش آمدید۔ یہ آپ کا اپنا مقامی اے آئی ویڈیو اسٹوڈیو ہے۔ "
        "کردار کی تصویر اپ لوڈ کریں، اسکرپٹ لکھیں، آواز منتخب کریں اور ایک خوبصورت ایچ ڈی ویڈیو تیار کریں۔ "
        "یہ سب آپ کے اپنے لیپ ٹاپ پر مفت چلتا ہے۔"
    ),
}

LOGO_SVG = (
    '<svg width="42" height="42" viewBox="0 0 32 32" fill="none">'
    '<rect x="1.5" y="5" width="23" height="18" rx="3.5" stroke="#22b8cf" stroke-width="2"/>'
    '<path d="M25 12.5l5.5-3.2v10.4L25 16.5z" fill="#6d5efc"/>'
    '<circle cx="9.5" cy="14" r="3.2" stroke="#6d5efc" stroke-width="2"/>'
    '<path d="M5 19.5c1.4-1.8 7.6-1.8 9 0" stroke="#22b8cf" stroke-width="2" stroke-linecap="round"/>'
    "</svg>"
)

TOP_BAR_HTML = f"""
<div class="topbar">
  <div class="brand">
    {LOGO_SVG}
    <div>
      <span class="brand-name">CineGen Studio</span>
      <span class="brand-sub">Local AI Video Studio &middot; Windows &middot; macOS &middot; Linux</span>
    </div>
  </div>
  <div class="badges">
    <span class="badge">v{__version__}</span>
    <span class="badge badge-ok">&#9679; 100% Local</span>
    <span class="badge">Free forever</span>
  </div>
</div>
"""

HERO_HTML = """
<div class="hero">
  <h1>Turn characters into <span>HD animated videos</span></h1>
  <p>Upload a character image, write a script, pick a voice &mdash; CineGen renders the finished video locally with voiceover, lip-sync, subtitles and music.</p>
  <p class="urdu">Aap ka apna AI video studio &mdash; bilkul local, bilkul free. اردو اور English، سب اپنے لیپ ٹاپ پر۔</p>
  <div>
    <span class="pill">🔒 Private</span><span class="pill">🗣️ 40+ languages</span><span class="pill">👄 CPU lip-sync</span><span class="pill">🎙️ Voice cloning</span><span class="pill">🎞️ 1080p / 4K</span><span class="pill">🚀 Wan2.2 AI Pro</span><span class="pill">💸 No subscription</span>
  </div>
  <div class="stats">
    <div class="stat"><b>178</b><span>local voices</span></div>
    <div class="stat"><b>40+</b><span>languages</span></div>
    <div class="stat"><b>1080p</b><span>up to 4K export</span></div>
    <div class="stat"><b>0</b><span>API keys</span></div>
  </div>
</div>
"""

FOOTER_HTML = f"""
<div class="cg-footer">
  <div>
    <b>🎬 CineGen Studio v{__version__}</b><br>
    Free, local, multilingual AI video tool.<br>
    App code MIT &middot; third-party licenses in <code>THIRD_PARTY_NOTICES.md</code>
  </div>
  <div style="text-align:right">
    Built with Piper TTS &middot; Chatterbox &middot; FFmpeg &middot; OpenCV<br>
    All processing happens on your machine &mdash; nothing is uploaded.<br>
    &copy; 2026 CineGen Studio contributors
  </div>
</div>
"""


def step_header(num: str, title: str, sub: str) -> str:
    return (
        f'<div class="step-head"><div class="step-num">{num}</div>'
        f'<div class="step-txt"><b>{title}</b><span>{sub}</span></div></div>'
    )

CSS = """
:root{--cg-panel:rgba(15,23,42,.72);--cg-line:rgba(148,163,184,.16);--cg-text:#eef2ff;--cg-muted:#94a3b8;--cg-indigo:#6d5efc;--cg-cyan:#22b8cf;--cg-grad:linear-gradient(100deg,#6d5efc,#22b8cf)}
/* ---------- base ---------- */
.gradio-container{background:radial-gradient(1200px 700px at 15% -10%,#1d2b64 0%,#0b1020 48%,#070a12 100%) fixed!important;color:var(--cg-text)!important;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Inter,Roboto,Helvetica,Arial,sans-serif!important;max-width:1240px!important;margin:0 auto!important}
.gradio-container ::selection{background:rgba(109,94,252,.45)}
.gradio-container ::-webkit-scrollbar{width:10px;height:10px}
.gradio-container ::-webkit-scrollbar-track{background:transparent}
.gradio-container ::-webkit-scrollbar-thumb{background:rgba(148,163,184,.28);border-radius:999px;border:2px solid transparent;background-clip:content-box}
.gradio-container ::-webkit-scrollbar-thumb:hover{background:rgba(148,163,184,.45);border:2px solid transparent;background-clip:content-box}
footer{display:none!important}
/* ---------- top bar ---------- */
.topbar{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:14px 22px;margin-bottom:14px;background:rgba(15,23,42,.66);border:1px solid var(--cg-line);border-radius:18px;backdrop-filter:blur(8px)}
.topbar .brand{display:flex;align-items:center;gap:14px}
.topbar .brand-name{font-size:1.3rem;font-weight:800;letter-spacing:-.02em;display:block;line-height:1.25}
.topbar .brand-sub{font-size:.78rem;color:var(--cg-muted);letter-spacing:.02em}
.topbar .badges{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}
.badge{font-size:.74rem;font-weight:700;padding:4px 12px;border-radius:999px;background:rgba(99,102,241,.16);border:1px solid rgba(165,180,252,.28);color:#c7d2fe;white-space:nowrap}
.badge-ok{background:rgba(52,211,153,.12);border-color:rgba(52,211,153,.35);color:#6ee7b7}
/* ---------- hero ---------- */
.hero{position:relative;padding:34px 30px 26px;border-radius:22px;margin-bottom:16px;background:linear-gradient(115deg,rgba(99,102,241,.26),rgba(34,184,207,.10) 55%,rgba(15,23,42,.85));border:1px solid rgba(165,180,252,.26);overflow:hidden}
.hero:after{content:"";position:absolute;inset:0;background:radial-gradient(600px 220px at 85% -40%,rgba(34,184,207,.18),transparent 70%);pointer-events:none}
.hero h1{margin:0 0 10px;font-size:2.05rem;line-height:1.15;letter-spacing:-.035em;font-weight:800}
.hero h1 span{background:var(--cg-grad);-webkit-background-clip:text;background-clip:text;color:transparent}
.hero p{margin:4px 0;color:#c7d2fe;font-size:1.02rem}
.hero .urdu{color:var(--cg-muted);font-size:.95rem}
.pill{display:inline-block;padding:4px 12px;margin:4px 6px 0 0;border-radius:999px;background:rgba(99,102,241,.15);border:1px solid rgba(165,180,252,.24);font-size:.8rem;color:#c7d2fe}
.stats{display:flex;gap:12px;flex-wrap:wrap;margin-top:18px}
.stat{flex:1;min-width:130px;background:rgba(7,10,18,.5);border:1px solid var(--cg-line);border-radius:14px;padding:12px 10px;text-align:center}
.stat b{display:block;font-size:1.45rem;letter-spacing:-.02em;background:var(--cg-grad);-webkit-background-clip:text;background-clip:text;color:transparent}
.stat span{font-size:.76rem;color:var(--cg-muted)}
/* ---------- step headers ---------- */
.step-head{display:flex;align-items:center;gap:12px;margin:2px 0 12px}
.step-num{flex:none;width:34px;height:34px;border-radius:11px;background:var(--cg-grad);display:flex;align-items:center;justify-content:center;font-weight:800;color:#fff;font-size:.95rem;box-shadow:0 6px 18px rgba(109,94,252,.35)}
.step-txt b{display:block;font-size:1rem;letter-spacing:-.01em;line-height:1.3}
.step-txt span{font-size:.8rem;color:var(--cg-muted)}
/* ---------- blocks & inputs ---------- */
.gradio-container .gr-panel,.gradio-container .gr-box{background:var(--cg-panel)!important;border:1px solid var(--cg-line)!important;border-radius:16px!important;box-shadow:0 12px 32px rgba(2,6,23,.32)!important}
.gradio-container .block{background:rgba(15,23,42,.5)!important;border:1px solid var(--cg-line)!important;border-radius:14px!important}
.gradio-container input[type="text"],.gradio-container textarea{background:#0b1020!important;border:1px solid var(--cg-line)!important;border-radius:10px!important;color:var(--cg-text)!important}
.gradio-container input[type="text"]:focus,.gradio-container textarea:focus{border-color:rgba(109,94,252,.65)!important;box-shadow:0 0 0 3px rgba(109,94,252,.18)!important}
.gradio-container label span,.gradio-container .label-wrap{color:#cbd5e1!important}
.gradio-container input[type="checkbox"],.gradio-container input[type="radio"]{accent-color:#6d5efc}
.gradio-container :focus-visible{outline:2px solid rgba(34,184,207,.6);outline-offset:2px}
/* ---------- buttons ---------- */
.gradio-container button{border-radius:12px!important;transition:transform .15s ease,box-shadow .15s ease,filter .15s ease,border-color .15s ease}
.gradio-container button.primary{background:var(--cg-grad)!important;border:none!important;color:#fff!important;font-weight:700!important;box-shadow:0 10px 26px rgba(109,94,252,.35)!important}
.gradio-container button.primary:hover{transform:translateY(-1px);filter:brightness(1.07)}
.gradio-container button.secondary{background:rgba(15,23,42,.6)!important;border:1px solid var(--cg-line)!important;color:#e2e8f0!important}
.gradio-container button.secondary:hover{border-color:rgba(109,94,252,.55)!important;transform:translateY(-1px)}
.gradio-container button.stop{background:rgba(248,113,113,.14)!important;border:1px solid rgba(248,113,113,.4)!important;color:#fca5a5!important}
.generate-btn{height:58px!important;font-size:1.12rem!important;letter-spacing:-.01em}
/* ---------- tabs ---------- */
.gradio-container .tab-nav{background:rgba(15,23,42,.6)!important;border:1px solid var(--cg-line)!important;border-radius:16px!important;padding:6px!important;gap:4px!important;backdrop-filter:blur(8px)}
.gradio-container .tab-item{border-radius:11px!important;border:none!important;font-weight:600!important;color:var(--cg-muted)!important;padding:9px 16px!important;font-size:.93rem!important}
.gradio-container .tab-item:hover{color:#e2e8f0!important}
.gradio-container .tab-item.selected{background:var(--cg-grad)!important;color:#fff!important;box-shadow:0 8px 22px rgba(109,94,252,.35)}
/* ---------- accordions ---------- */
.gradio-container .accordion{border-radius:16px!important;border:1px solid var(--cg-line)!important;background:rgba(15,23,42,.55)!important}
/* ---------- tables ---------- */
.gradio-container table{border-collapse:collapse!important;width:100%!important}
.gradio-container th{background:rgba(30,41,59,.85)!important;color:#c7d2fe!important;font-size:.78rem!important;text-transform:uppercase;letter-spacing:.06em;font-weight:700!important;border-bottom:1px solid var(--cg-line)!important;padding:9px 12px!important}
.gradio-container td{border-bottom:1px solid rgba(148,163,184,.1)!important;font-size:.9rem!important;color:#cbd5e1!important;padding:8px 12px!important}
.gradio-container tr:hover td{background:rgba(99,102,241,.06)!important}
/* ---------- callouts ---------- */
.callout{border-radius:14px;padding:14px 18px;border:1px solid var(--cg-line);background:rgba(15,23,42,.6);margin:2px 0}
.callout-title{font-weight:800;font-size:1.02rem;margin-bottom:4px;color:#f1f5f9}
.callout-body{font-size:.92rem;color:#cbd5e1;line-height:1.55}
.callout-body code{background:rgba(7,10,18,.7);padding:2px 7px;border-radius:7px;font-size:.84rem;color:#a5f3fc}
.callout-body a{color:#93c5fd}
.callout-ok{border-color:rgba(52,211,153,.4);background:rgba(52,211,153,.07)}
.callout-error{border-color:rgba(248,113,113,.45);background:rgba(248,113,113,.08)}
.callout-warn{border-color:rgba(251,191,36,.4);background:rgba(251,191,36,.07)}
.callout-work{border-color:rgba(109,94,252,.45);background:rgba(99,102,241,.1)}
/* ---------- misc ---------- */
.statusbox{min-height:92px}
.small-note{color:var(--cg-muted);font-size:.88rem}
/* ---------- chat studio ---------- */
.chatbox{border-radius:16px!important}
.gradio-container .bubble-wrap .bubble{border-radius:14px!important;font-size:.95rem!important}
.gradio-container .user-row .bubble{background:rgba(99,102,241,.24)!important;border:1px solid rgba(165,180,252,.3)!important}
.gradio-container .bot-row .bubble{background:rgba(15,23,42,.78)!important;border:1px solid var(--cg-line)!important}
.chat-send{min-height:88px!important}
.cg-footer{margin-top:26px;padding:22px 26px;border-top:1px solid var(--cg-line);display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap;color:var(--cg-muted);font-size:.85rem}
.cg-footer b{color:#e2e8f0}
.cg-footer a{color:#a5b4fc}
"""


def status(title: str, message: str = "", kind: str = "info") -> str:
    icons = {"info": "ℹ️", "ok": "✅", "warn": "⚠️", "error": "⛔", "work": "⏳"}
    text = html.escape(message or "")
    text = re.sub(r"`([^`]+)`", r"<code>\1</code>", text)
    text = re.sub(r"\*\*([^*]+)\*\*", r"<b>\1</b>", text)
    text = re.sub(r"(https?://[^\s<]+)", r'<a href="\1" target="_blank" rel="noopener">\1</a>', text)
    text = text.replace("\n", "<br>")
    return (
        f"<div class='callout callout-{html.escape(kind)}'>"
        f"<div class='callout-title'>{icons.get(kind, 'ℹ️')} {html.escape(title)}</div>"
        f"<div class='callout-body'>{text}</div></div>"
    )


def safe_stem(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]+", "_", text)[:60].strip("_") or "video"


def ensure_sample_image() -> Path:
    if not SAMPLE_IMAGE.exists():
        make_placeholder_character(SAMPLE_IMAGE)
    return SAMPLE_IMAGE


def installed_voice_markdown() -> str:
    keys = installed_voices()
    if not keys:
        return "### Installed voice models\n\n_No voice models downloaded yet. The selected voice downloads automatically on first use._"
    lines = ["### Installed voice models", "", "| Voice | Language | Quality |", "|---|---|---|"]
    from cinegen.catalog import CATALOG

    for key in sorted(keys):
        info = CATALOG[key]
        lines.append(
            f"| `{key}` | {info['language'].get('name_english', '')} | {info['quality']} |"
        )
    return "\n".join(lines)


def system_markdown() -> str:
    report = system_report()
    ready, note = pro_readiness()
    gpu_lines = ""
    for gpu in report["nvidia_gpus"]:
        gpu_lines += f"- **{gpu['name']}** — {gpu['vram_mb']/1024:.1f} GB VRAM, driver {gpu['driver']}\n"
    if not gpu_lines:
        gpu_lines = "- No NVIDIA GPU detected via `nvidia-smi`.\n"
    return f"""### 💻 System report

- **OS:** {report['os']} ({report['architecture']})
- **Python:** {report['python']}
- **CPU threads:** {report['cpu_cores']}
- **RAM:** {report['ram_gb']} GB
- **Free disk:** {report['disk_free_gb']} GB
- **FFmpeg:** `{html.escape(report['ffmpeg'])}`

#### Graphics

{gpu_lines}
- **AI Pro readiness:** {'✅' if ready else '⚠️'} {html.escape(note)}

#### Important

- Standard Studio works on CPU and creates 1080p/4K videos with cinematic motion, voiceover and subtitles.
- AI Pro needs ComfyUI running locally plus approximately 17 GB of Wan2.2 model files and an NVIDIA GPU with 8 GB+ VRAM.
- After the models are downloaded, generation is offline. No paid API key is required.
"""


def voice_clone_status_markdown() -> str:
    info = availability()
    if info.get("available"):
        return status(
            "Voice cloning is ready",
            f"Chatterbox Multilingual V3 detected. Recommended device: `{info['device']}`.\n\n"
            "The first generation downloads roughly 1–2 GB of model weights, then runs locally.",
            "ok",
        )
    return status(
        "Voice cloning is optional and not installed yet",
        "Install it once with:\n\n```bash\n"
        + install_instructions()
        + "\n```\n\n"
        + f"Details: {info.get('error', 'unknown')}\n\n"
        "Piper preset voices and all other features continue to work without it.",
        "warn",
    )


CHAT_WELCOME = [
    {
        "role": "assistant",
        "content": (
            "👋 **Welcome to Chat Studio!**\n\n"
            "1. Upload your character image on the left (or start with the demo character)\n"
            "2. Type your script below and press **Enter** — each message becomes one animated section\n"
            "3. Send more messages for more sections, in any order you like\n"
            "4. Press **Combine all sections** for the final video\n\n"
            "Har message = aik naya section. Jab dil chahaye, naya script bhejein! 🎬"
        ),
    }
]


def sections_markdown(state: dict | None) -> str:
    if not state or not state.get("sections"):
        return "<div class='callout'><div class='callout-body'>📄 <b>0 sections</b> &middot; total 0.0s</div></div>"
    total = sum(section["duration"] for section in state["sections"])
    count = len(state["sections"])
    plural = "s" if count > 1 else ""
    return (
        f"<div class='callout callout-ok'><div class='callout-body'>"
        f"📄 <b>{count} section{plural}</b> &middot; total {total:.1f}s &middot; ready to combine"
        f"</div></div>"
    )


def _ensure_chat_state(state: dict | None) -> dict:
    if state and isinstance(state, dict) and "job_dir" in state:
        return state
    return new_project()


def chat_send(
    message,
    history,
    state,
    images,
    language,
    voice_key,
    style,
    resolution_name,
    intensity,
    speed,
    subtitles,
    progress=gr.Progress(),
):
    message = (message or "").strip()
    history = list(history or [])
    if not message:
        yield history, state, gr.update(), status("Empty message", "Type a script first.", "warn"), sections_markdown(state)
        return

    history.append({"role": "user", "content": message})
    history.append({"role": "assistant", "content": "⏳ Generating section… voice + animation + subtitles"})
    yield history, state, gr.update(value=""), status(
        "Working", "Generating your section — first voice, then animation.", "work"
    ), sections_markdown(state)

    try:
        if not voice_key:
            voice_key = recommended_voice(language) or "en_US-amy-medium"

        def report(fraction, note):
            progress(min(0.99, max(0.0, fraction)), desc=note)

        state = _ensure_chat_state(state)
        entry = generate_section(
            state,
            message,
            images or [],
            voice_key,
            style=style,
            resolution_name=resolution_name,
            intensity=float(intensity),
            speed=float(speed),
            subtitles=bool(subtitles),
            progress=report,
        )
        used_demo = not images
        reply = (
            f"✅ **Section {entry['index'] + 1}** created — {entry['duration']:.1f}s • "
            f"{entry['sentences']} sentence(s) • voice `{voice_key}` • {entry['width']}×{entry['height']}"
        )
        if used_demo:
            reply += "\n\n_Character: demo sample — upload your own on the left._"
        reply += "\n\nSend another message for the next section, or press **Combine all sections** for the final video."
        history[-1] = {"role": "assistant", "content": reply}
        history.append({"role": "assistant", "content": (entry["video"], "Section video")})
        yield history, state, gr.update(value=""), status(
            "Section ready",
            f"Section {entry['index'] + 1} • {entry['duration']:.1f}s. Send another message or combine.",
            "ok",
        ), sections_markdown(state)
    except Exception as exc:
        history[-1] = {"role": "assistant", "content": f"⛔ **Section failed** — {type(exc).__name__}: {exc}"}
        yield history, state, gr.update(), status("Section failed", f"{type(exc).__name__}: {exc}", "error"), sections_markdown(state)


def chat_combine(history, state, resolution_name, music_file, music_volume, progress=gr.Progress()):
    history = list(history or [])
    if not state or not state.get("sections"):
        yield history, state, status("Nothing to combine", "Send at least one script message first.", "warn"), None, None, None
        return

    history.append({"role": "assistant", "content": "⏳ Combining all sections into the final video…"})
    yield history, state, status("Working", "Joining sections, rebuilding subtitles, mixing audio…", "work"), None, None, None
    try:
        def report(fraction, note):
            progress(min(0.99, max(0.0, fraction)), desc=note)

        music = None
        if music_file:
            music = Path(music_file if isinstance(music_file, str) else music_file.name)
        result = combine_sections(
            state,
            resolution_name,
            music_path=music,
            music_volume=float(music_volume),
            subtitles=True,
            progress=report,
        )
        reply = (
            f"🎉 **Final video ready** — {result['count']} sections • {result['duration']:.1f}s\n\n"
            f"Saved to `outputs/`. Preview and downloads are below the chat."
        )
        history[-1] = {"role": "assistant", "content": reply}
        history.append({"role": "assistant", "content": (result["final"], "Final video")})
        yield (
            history,
            state,
            status(
                "Final video ready",
                f"{result['count']} sections • {result['duration']:.1f}s • {result['final']}",
                "ok",
            ),
            result["final"],
            result["final"],
            result["srt"],
        )
    except Exception as exc:
        history[-1] = {"role": "assistant", "content": f"⛔ **Combine failed** — {type(exc).__name__}: {exc}"}
        yield history, state, status("Combine failed", f"{type(exc).__name__}: {exc}", "error"), None, None, None


def chat_new():
    history = [
        {
            "role": "assistant",
            "content": (
                "🧹 **New project started.**\n\nUpload a character, type your script and press Enter — "
                "each message becomes one animated section."
            ),
        }
    ]
    return (
        history,
        None,
        status("New project", "Previous sections stay on disk under work/ — the chat starts fresh.", "info"),
        None,
        None,
        None,
        sections_markdown(None),
    )


def comfy_status_markdown(url: str) -> str:
    result = comfy_status(url)
    if result.get("online"):
        devices = result.get("devices", [])
        device_lines = "".join(
            f"- {html.escape(str(d.get('name', 'device')))} — {html.escape(str(d.get('type', '')))}\n"
            for d in devices[:4]
        )
        return status(
            "ComfyUI is online",
            f"Version: {result.get('version', 'unknown')}\n\n{device_lines or 'No device details returned.'}",
            "ok",
        )
    return status(
        "ComfyUI is not reachable",
        f"URL: {url}\nError: {result.get('error', 'unknown')}\n\nStart ComfyUI first, then try again.",
        "error",
    )


def pro_models_markdown(comfy_path: str) -> str:
    if not comfy_path.strip():
        return status("ComfyUI folder not set", "Enter the full path to your ComfyUI folder in Global / AI Pro settings.", "warn")
    try:
        report = check_pro_models(Path(comfy_path))
    except Exception as exc:
        return status("Could not inspect ComfyUI folder", str(exc), "error")
    lines = ["| Model | File | Status | Size |", "|---|---|---|---|"]
    for item in report:
        state = "✅ Ready" if item["installed"] else ("⏳ Partial download" if item["partial"] else "⬇️ Missing")
        lines.append(f"| {item['name']} | `{item['filename']}` | {state} | {item['size']} |")
    return "### Wan2.2 Pro model status\n\n" + "\n".join(lines)


def ai_native_resolution(width: int, height: int) -> tuple[int, int]:
    ratio = width / height
    if ratio >= 1.4:
        return 1280, 704
    if ratio <= 0.75:
        return 704, 1280
    return 960, 960


def create_project_zip(
    zip_path: Path,
    final_video: Path,
    srt_path: Path,
    ass_path: Path,
    voice_wav: Path,
    metadata: dict,
) -> Path:
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    metadata_path = zip_path.parent / "project_settings.json"
    metadata_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.write(final_video, arcname=final_video.name)
        archive.write(srt_path, arcname=srt_path.name)
        archive.write(ass_path, arcname=ass_path.name)
        archive.write(voice_wav, arcname=voice_wav.name)
        archive.write(metadata_path, arcname="project_settings.json")
        note = (
            "CineGen Studio project\n\n"
            "This archive contains the final video, timed subtitles, voiceover and settings.\n"
            "The generated video and audio belong to you. Third-party model licenses remain\n"
            "governed by their upstream model cards; see THIRD_PARTY_NOTICES.md.\n"
        )
        archive.writestr("README.txt", note)
    return zip_path


def build_demo(language: str):
    script = DEMO_SCRIPTS.get(language, DEMO_SCRIPTS["en_US"])
    voice = recommended_voice(language)
    return (
        [str(ensure_sample_image())],
        script,
        language,
        gr.update(choices=voice_choices(language), value=voice),
    )


def generate_video(
    images,
    script,
    language,
    voice_key,
    voice_engine,
    reference_audio,
    clone_language,
    clone_device,
    mode,
    resolution_name,
    animation_style,
    motion_intensity,
    voice_speed,
    subtitles_enabled,
    music_file,
    music_volume,
    comfy_url,
    ai_steps,
    motion_prompt,
    negative_prompt,
    progress=gr.Progress(),
):
    outputs = 5
    empty = (None, None, None, None)

    def report(fraction: float, message: str):
        progress(min(0.99, max(0.0, fraction)), desc=message)

    try:
        settings = load_settings()
        save_settings(
            {
                "comfy_url": comfy_url,
                "last_language": language,
                "last_voice": voice_key,
                "last_voice_engine": voice_engine,
                "last_clone_language": clone_language,
                "last_clone_device": clone_device,
                "last_resolution": resolution_name,
                "last_mode": mode,
                "last_voice_speed": voice_speed,
                "last_music_volume": music_volume,
                "last_motion_intensity": motion_intensity,
                "last_motion_prompt": motion_prompt,
                "last_negative_prompt": negative_prompt,
            }
        )

        if not images:
            yield status("No character image", "Upload at least one character image.", "error"), *empty
            return
        if not script or not script.strip():
            yield status("No script", "Write the voiceover script first.", "error"), *empty
            return
        use_voice_clone = str(voice_engine).startswith("Voice Clone")
        clone_language = clone_language or "en"
        clone_device = clone_device or "auto"
        if use_voice_clone:
            if not reference_audio:
                yield status(
                    "Reference voice missing",
                    "Upload a clean 5–10 second voice sample in the Voice cloning accordion.",
                    "error",
                ), *empty
                return
            voice_key = f"chatterbox-clone:{clone_language}"
        else:
            if not voice_key:
                voice_key = recommended_voice(language)
            if not voice_key:
                yield status("No voice selected", "Choose a language and voice model.", "error"), *empty
                return
        if resolution_name not in RESOLUTIONS:
            yield status("Invalid resolution", "Choose a supported resolution.", "error"), *empty
            return

        image_paths = [Path(p) for p in (images if isinstance(images, list) else [images])]
        if mode.startswith("AI Pro") and len(image_paths) > 12:
            image_paths = image_paths[:12]
            yield status(
                "Too many AI Pro scenes",
                "AI Pro will use the first 12 images to keep GPU time manageable.",
                "warn",
            ), *empty

        job_id = datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:6]
        job_dir = WORK_DIR / job_id
        input_dir = job_dir / "inputs"
        scene_dir = job_dir / "scenes"
        ai_dir = job_dir / "ai_clips"
        for directory in (job_dir, input_dir, scene_dir, ai_dir):
            directory.mkdir(parents=True, exist_ok=True)

        local_images = []
        for index, source in enumerate(image_paths):
            target = input_dir / f"character_{index:02d}{Path(source).suffix.lower() or '.png'}"
            shutil.copy2(source, target)
            local_images.append(target)

        local_music = None
        if music_file:
            source = Path(music_file if isinstance(music_file, str) else music_file.name)
            if source.exists():
                local_music = job_dir / f"background_music{source.suffix.lower()}"
                shutil.copy2(source, local_music)

        local_reference = None
        if use_voice_clone:
            source = Path(reference_audio if isinstance(reference_audio, str) else reference_audio.name)
            if not source.exists():
                yield status("Reference voice missing", "The uploaded voice sample could not be read.", "error"), *empty
                return
            local_reference = job_dir / f"reference_voice{source.suffix.lower() or '.wav'}"
            shutil.copy2(source, local_reference)

        width, height = RESOLUTIONS[resolution_name]
        sentences = split_script(script)
        if not sentences:
            yield status("Empty script", "The script did not contain any speakable text.", "error"), *empty
            return
        groups = partition_sentences(sentences, len(local_images))

        engine_label = "Chatterbox voice clone" if use_voice_clone else "Piper local TTS"
        download_note = (
            "The first clone generation downloads about 1–2 GB of model weights."
            if use_voice_clone
            else "The selected voice model downloads once if it is not already on your laptop."
        )
        yield status(
            "Preparing voiceover",
            f"Engine: `{engine_label}` • Language: `{language}` • Voice: `{voice_key}` • Scenes: {len(groups)}\n\n"
            + download_note,
            "work",
        ), *empty
        report(0.02, "Preparing local voice model…")

        tts_result = synthesize_scenes(
            groups=groups,
            voice_key=voice_key,
            output_dir=job_dir / "audio",
            speech_rate=float(voice_speed),
            sentence_pause=0.18,
            lead_in=0.35,
            tail=0.45,
            resolution=(width, height),
            voice_engine="clone" if use_voice_clone else "piper",
            reference_audio=local_reference,
            clone_language_id=clone_language,
            clone_device=clone_device,
            progress=lambda fraction, message: report(0.03 + 0.47 * fraction, message),
        )
        scenes = tts_result["scenes"]
        total_duration = tts_result["total_duration"]

        yield status(
            "Voiceover ready",
            f"Duration: {total_duration:.1f}s • {len(tts_result['segments'])} subtitle cues.\n\n"
            f"Now rendering {len(scenes)} scene(s) in {resolution_name}.",
            "work",
        ), *empty

        scene_videos = []
        if mode.startswith("AI Pro"):
            client = ComfyClient(comfy_url or settings.get("comfy_url") or DEFAULT_SETTINGS["comfy_url"])
            try:
                stats = client.system_stats()
            except Exception as exc:
                raise RuntimeError(
                    "Cannot reach ComfyUI. Start ComfyUI and check the URL in Global / AI Pro settings. "
                    f"Details: {exc}"
                ) from exc
            native_w, native_h = ai_native_resolution(width, height)
            script_excerpt = " ".join(sentences)[:380]
            positive_prompt = (
                (motion_prompt or DEFAULT_SETTINGS["last_motion_prompt"]).strip()
                + f" Visual story context: {script_excerpt}"
            )
            negative = (negative_prompt or DEFAULT_SETTINGS["last_negative_prompt"]).strip()
            for index, (scene, image_path) in enumerate(zip(scenes, local_images)):
                start = 0.52 + 0.30 * index / max(1, len(scenes))
                end = 0.52 + 0.30 * (index + 1) / max(1, len(scenes))
                yield status(
                    "AI Pro generation",
                    f"Scene {index + 1}/{len(scenes)} — Wan2.2 is generating motion from your character image. "
                    "This is the slowest step and depends on your GPU.",
                    "work",
                ), *empty
                ai_input = prepare_ai_input(image_path, job_dir / f"ai_input_{index:03d}.jpg", native_w, native_h)
                length = max(25, min(121, int(scene["duration"] * 24)))
                config = {
                    "positive_prompt": positive_prompt,
                    "negative_prompt": negative,
                    "width": native_w,
                    "height": native_h,
                    "length": length,
                    "fps": 24,
                    "seed": random.randint(1, 2**31 - 1),
                    "steps": int(ai_steps),
                    "cfg": 5.0,
                    "filename_prefix": f"CineGen/{job_id}_scene_{index:03d}",
                    "shift": 8.0,
                }
                clip = client.generate_clip(
                    ai_input,
                    config,
                    ai_dir,
                    progress=lambda fraction, message, _s=start, _e=end: report(
                        _s + (_e - _s - 0.02) * fraction, message
                    ),
                    timeout=3600,
                )
                scene_video = scene_dir / f"ai_scene_{index:03d}.mp4"
                loop_trim_clip(
                    clip,
                    scene_video,
                    scene["duration"],
                    width,
                    height,
                    progress=lambda fraction, message, _s=end - 0.02, _e=end: report(
                        _s + (_e - _s) * fraction, f"Preparing AI scene {index + 1}: {message}"
                    ),
                )
                scene_videos.append(scene_video)
        else:
            for index, (scene, image_path) in enumerate(zip(scenes, local_images)):
                start = 0.52 + 0.30 * index / max(1, len(scenes))
                end = 0.52 + 0.30 * (index + 1) / max(1, len(scenes))
                background, foreground = prepare_scene_assets(
                    image_path,
                    job_dir / f"assets_{index:03d}",
                    width,
                    height,
                )
                scene["background"] = background
                scene["foreground"] = foreground
                scene["image_path"] = image_path
                scene_video = scene_dir / f"standard_scene_{index:03d}.mp4"
                if animation_style == "Lip Sync Avatar":
                    render_lipsync_scene(
                        scene,
                        scene_video,
                        width,
                        height,
                        intensity=float(motion_intensity),
                        progress=lambda fraction, message, _s=start, _e=end: report(
                            _s + (_e - _s) * fraction, f"Scene {index + 1}: {message}"
                        ),
                    )
                else:
                    render_standard_scene(
                        scene,
                        scene_video,
                        width,
                        height,
                        style=animation_style,
                        intensity=float(motion_intensity),
                        progress=lambda fraction, message, _s=start, _e=end: report(
                            _s + (_e - _s) * fraction, f"Scene {index + 1}: {message}"
                        ),
                    )
                scene_videos.append(scene_video)

        yield status("Compositing final video", "Joining scenes, adding voiceover, subtitles and music fades…", "work"), *empty
        silent_video = concat_scenes(scene_videos, job_dir / "silent_video.mp4")
        final_name = f"CineGen_{safe_stem(language)}_{job_id}.mp4"
        final_video = OUTPUT_DIR / final_name
        mux_final(
            silent_video=silent_video,
            voice_wav=tts_result["full_voice_wav"],
            output_path=final_video,
            duration=total_duration,
            width=width,
            height=height,
            music_path=local_music,
            music_volume=float(music_volume),
            subtitle_path=tts_result["ass_path"] if subtitles_enabled else None,
            progress=lambda fraction, message: report(0.84 + 0.14 * fraction, message),
        )

        metadata = {
            "app": "CineGen Studio",
            "version": __version__,
            "created": datetime.now().isoformat(timespec="seconds"),
            "job_id": job_id,
            "mode": mode,
            "resolution": [width, height],
            "duration_seconds": round(total_duration, 3),
            "language": tts_result.get("language", language),
            "voice": tts_result.get("voice_key", voice_key),
            "voice_engine": tts_result.get("voice_engine", "clone" if use_voice_clone else "piper"),
            "reference_voice": local_reference.name if local_reference else None,
            "subtitles_burned_in": bool(subtitles_enabled),
            "background_music": local_music.name if local_music else None,
            "character_images": [p.name for p in local_images],
            "script": script,
            "comfy_url": comfy_url if mode.startswith("AI Pro") else None,
        }
        project_zip = create_project_zip(
            OUTPUT_DIR / f"{Path(final_name).stem}_project.zip",
            final_video,
            tts_result["srt_path"],
            tts_result["ass_path"],
            tts_result["full_voice_wav"],
            metadata,
        )
        report(1.0, "Complete")
        yield (
            status(
                "Video is ready",
                f"`{final_video.name}` • {total_duration:.1f}s • {width}×{height}\n\n"
                "Download the MP4, subtitles, or the complete project ZIP below.",
                "ok",
            ),
            str(final_video),
            str(final_video),
            str(tts_result["srt_path"]),
            str(project_zip),
        )
    except Exception as exc:
        error_log = WORK_DIR / "last_error.log"
        error_log.parent.mkdir(exist_ok=True)
        error_log.write_text(traceback.format_exc(), encoding="utf-8")
        yield (
            status(
                "Generation failed",
                f"{type(exc).__name__}: {exc}\n\nFull technical details saved to `work/last_error.log`.",
                "error",
            ),
            *empty,
        )


def install_voice_action(language, voice_key, progress=gr.Progress()):
    if not voice_key:
        return status("No voice selected", "Choose a voice model first.", "warn"), gr.update(), installed_voice_markdown()
    try:
        def report(fraction, message):
            progress(fraction, desc=message)

        ensure_voice(voice_key, report)
        return (
            status(
                "Voice model ready",
                f"`{voice_key}` is installed locally.\n\n"
                f"License/model card: {model_card_url(voice_key)}",
                "ok",
            ),
            gr.update(choices=voice_choices(language), value=voice_key),
            installed_voice_markdown(),
        )
    except Exception as exc:
        return status("Voice download failed", str(exc), "error"), gr.update(), installed_voice_markdown()


def delete_voice_action(language, voice_key):
    if not voice_key:
        return status("No voice selected", "Choose a voice model first.", "warn"), gr.update(), installed_voice_markdown()
    message = delete_voice(voice_key)
    return (
        status("Voice removed", message, "ok"),
        gr.update(choices=voice_choices(language), value=recommended_voice(language)),
        installed_voice_markdown(),
    )


def install_pro_action(comfy_path, progress=gr.Progress()):
    try:
        def report(fraction, message):
            progress(fraction, desc=message)

        paths = install_pro_models(Path(comfy_path), report)
        return status(
            "Wan2.2 Pro models installed",
            f"{len(paths)} model file(s) are ready.\n\n" + pro_models_markdown(comfy_path),
            "ok",
        )
    except Exception as exc:
        return status("Pro model installation failed", str(exc), "error")


def build_ui() -> gr.Blocks:
    settings = load_settings()
    languages = language_choices()
    default_language = settings.get("last_language", "en_US")
    if default_language not in [code for _, code in languages]:
        default_language = "en_US"
    default_voice = settings.get("last_voice") or recommended_voice(default_language)

    with gr.Blocks(
        title="CineGen Studio — Free Local AI Video Tool",
        theme=gr.themes.Soft(
            primary_hue="indigo",
            secondary_hue="cyan",
            neutral_hue="slate",
        ),
        css=CSS,
    ) as demo:
        gr.HTML(TOP_BAR_HTML)
        gr.HTML(HERO_HTML)

        with gr.Accordion("⚙️ Global / AI Pro settings", open=False):
            with gr.Row():
                comfy_url = gr.Textbox(
                    value=settings.get("comfy_url", DEFAULT_SETTINGS["comfy_url"]),
                    label="ComfyUI server URL",
                    info="Only needed for AI Pro mode. Local default: http://127.0.0.1:8188",
                )
                comfy_path = gr.Textbox(
                    value=settings.get("comfy_path", ""),
                    label="ComfyUI folder path",
                    info="Full path to your ComfyUI folder, used to download the 17 GB Wan2.2 model set.",
                    placeholder="C:\\AI\\ComfyUI  or  /home/user/ComfyUI",
                )
            with gr.Row():
                ai_steps = gr.Slider(10, 30, value=20, step=1, label="AI Pro sampling steps")
                save_global = gr.Button("💾 Save global settings", variant="secondary")
            motion_prompt = gr.Textbox(
                value=settings.get("last_motion_prompt", DEFAULT_SETTINGS["last_motion_prompt"]),
                label="AI Pro motion prompt (English recommended)",
                lines=3,
            )
            negative_prompt = gr.Textbox(
                value=settings.get("last_negative_prompt", DEFAULT_SETTINGS["last_negative_prompt"]),
                label="AI Pro negative prompt",
                lines=2,
            )
            global_status = gr.Markdown("")

            def save_global_action(url, path, motion, negative):
                save_settings(
                    {
                        "comfy_url": url,
                        "comfy_path": path,
                        "last_motion_prompt": motion,
                        "last_negative_prompt": negative,
                    }
                )
                return status("Global settings saved", "ComfyUI URL, folder path and prompt defaults are stored in settings.json.", "ok")

            save_global.click(save_global_action, [comfy_url, comfy_path, motion_prompt, negative_prompt], [global_status])

        with gr.Accordion("🎙️ Voice cloning (optional)", open=False):
            gr.Markdown(
                """
                Use a clean 5–10 second voice sample to speak your script in that voice.
                This uses **Chatterbox Multilingual V3** (MIT) locally. It is optional: Piper preset voices,
                lip-sync, subtitles and AI Pro all work without it.
                """
            )
            voice_engine = gr.Radio(
                choices=["Piper preset voices", "Voice Clone (Chatterbox)"],
                value=settings.get("last_voice_engine", "Piper preset voices"),
                label="Voice engine",
            )
            with gr.Row():
                reference_audio = gr.File(
                    file_types=["audio"],
                    type="filepath",
                    label="Reference voice sample (5–10 seconds)",
                )
                clone_language = gr.Dropdown(
                    choices=[(code.upper(), code) for code in VOICE_CLONE_LANGUAGES],
                    value=settings.get("last_clone_language", "en"),
                    label="Clone language",
                )
                clone_device = gr.Dropdown(
                    choices=["auto", "cpu", "cuda", "mps"],
                    value=settings.get("last_clone_device", "auto"),
                    label="Clone device",
                )
            with gr.Row():
                check_clone_btn = gr.Button("🔍 Check voice cloning", variant="secondary")
                clone_status = gr.Markdown(voice_clone_status_markdown())
            check_clone_btn.click(lambda: voice_clone_status_markdown(), [], [clone_status])

        with gr.Tabs():
            with gr.TabItem("💬 Chat Studio"):
                with gr.Row():
                    with gr.Column(scale=2):
                        gr.HTML(step_header("💬", "Chat", "Type your script — each message becomes one animated section with your character"))
                        chatbot = gr.Chatbot(
                            value=CHAT_WELCOME,
                            type="messages",
                            height=440,
                            elem_classes=["chatbox"],
                            label="Chat",
                            show_copy_button=True,
                        )
                        with gr.Row():
                            chat_input = gr.Textbox(
                                placeholder="Apni script likhein aur Enter dabayein… (Type your script and press Enter)",
                                lines=2,
                                show_label=False,
                                elem_classes=["chat-send"],
                            )
                            chat_send_btn = gr.Button("Send ▶", variant="primary")
                        chat_status = gr.Markdown(
                            status("Ready", "Send a script message to create your first section.", "info")
                        )
                        with gr.Row():
                            chat_combine_btn = gr.Button(
                                "🎬 Combine all sections → Final video",
                                variant="primary",
                                elem_classes=["generate-btn"],
                            )
                        chat_final_video = gr.Video(label="Final video")
                        with gr.Row():
                            chat_download_video = gr.File(label="Download final MP4", file_types=[".mp4"])
                            chat_download_srt = gr.File(label="Download SRT subtitles", file_types=[".srt"])

                    with gr.Column(scale=1):
                        gr.HTML(step_header("👤", "Character & Voice", "Upload your character once — every section uses it"))
                        chat_images = gr.File(
                            file_count="multiple",
                            file_types=["image"],
                            type="filepath",
                            label="Character images (optional — demo character used if empty)",
                        )
                        with gr.Row():
                            chat_language = gr.Dropdown(
                                choices=languages,
                                value=default_language,
                                label="Language",
                            )
                        chat_voice = gr.Dropdown(
                            choices=voice_choices(default_language),
                            value=default_voice,
                            label="Voice model",
                        )
                        gr.HTML(step_header("🎞️", "Animation & Output", "Style, resolution and fine-tuning"))
                        chat_style = gr.Dropdown(
                            choices=CHAT_STYLES,
                            value="Lip Sync Avatar",
                            label="Animation style",
                            info="Lip Sync Avatar: character's mouth moves with the voice (CPU).",
                        )
                        chat_resolution = gr.Dropdown(
                            choices=list(RESOLUTIONS.keys()),
                            value="720p",
                            label="Resolution",
                        )
                        chat_intensity = gr.Slider(0.1, 1.0, value=0.8, step=0.05, label="Motion intensity")
                        chat_speed = gr.Slider(0.7, 1.3, value=1.0, step=0.05, label="Voice speed")
                        chat_subtitles = gr.Checkbox(value=True, label="Burn subtitles into sections")
                        chat_music = gr.File(
                            file_types=["audio"],
                            type="filepath",
                            label="Background music for final video (optional)",
                        )
                        chat_music_volume = gr.Slider(0.0, 0.5, value=0.15, step=0.01, label="Music volume")
                        chat_sections_md = gr.Markdown(sections_markdown(None))
                        chat_new_btn = gr.Button("🧹 New project", variant="secondary")

                chat_state = gr.State(None)

                chat_input.submit(
                    chat_send,
                    [
                        chat_input,
                        chatbot,
                        chat_state,
                        chat_images,
                        chat_language,
                        chat_voice,
                        chat_style,
                        chat_resolution,
                        chat_intensity,
                        chat_speed,
                        chat_subtitles,
                    ],
                    [chatbot, chat_state, chat_input, chat_status, chat_sections_md],
                    queue=True,
                )
                chat_send_btn.click(
                    chat_send,
                    [
                        chat_input,
                        chatbot,
                        chat_state,
                        chat_images,
                        chat_language,
                        chat_voice,
                        chat_style,
                        chat_resolution,
                        chat_intensity,
                        chat_speed,
                        chat_subtitles,
                    ],
                    [chatbot, chat_state, chat_input, chat_status, chat_sections_md],
                    queue=True,
                )
                chat_combine_btn.click(
                    chat_combine,
                    [chatbot, chat_state, chat_resolution, chat_music, chat_music_volume],
                    [chatbot, chat_state, chat_status, chat_final_video, chat_download_video, chat_download_srt],
                    queue=True,
                )
                chat_new_btn.click(
                    chat_new,
                    [],
                    [
                        chatbot,
                        chat_state,
                        chat_status,
                        chat_final_video,
                        chat_download_video,
                        chat_download_srt,
                        chat_sections_md,
                    ],
                    queue=False,
                )
                chat_language.change(
                    lambda lang: gr.update(choices=voice_choices(lang), value=recommended_voice(lang)),
                    [chat_language],
                    [chat_voice],
                )

            with gr.TabItem("🎬 Create Video"):
                with gr.Row():
                    with gr.Column(scale=1):
                        gr.HTML(step_header("1", "Character & Script", "Upload one or more character images — each image becomes one scene"))
                        images_input = gr.File(
                            file_count="multiple",
                            file_types=["image"],
                            type="filepath",
                            label="Character images (one or more)",
                        )
                        with gr.Row():
                            demo_en = gr.Button("✨ Load English demo", variant="secondary")
                            demo_ur = gr.Button("✨ Load Urdu demo", variant="secondary")
                        script_input = gr.Textbox(
                            label="Voiceover script",
                            placeholder="Write your script here. Use the language of the selected voice.",
                            lines=9,
                        )
                        gr.HTML(step_header("2", "Voice & Language", "178 local voices · 40+ locales · optional voice cloning above"))
                        with gr.Row():
                            create_language = gr.Dropdown(
                                choices=languages,
                                value=default_language,
                                label="Language",
                            )
                            create_voice = gr.Dropdown(
                                choices=voice_choices(default_language),
                                value=default_voice,
                                label="Voice model (↓ downloads on first use)",
                            )
                        gr.HTML(step_header("3", "Motion, Music & Output", "Standard Studio works on any laptop · AI Pro needs ComfyUI + NVIDIA GPU"))
                        with gr.Row():
                            mode = gr.Radio(
                                choices=["Standard Studio", "AI Pro (ComfyUI)"],
                                value=settings.get("last_mode", "Standard Studio"),
                                label="Animation engine",
                            )
                            resolution = gr.Dropdown(
                                choices=list(RESOLUTIONS.keys()),
                                value=settings.get("last_resolution", "1080p"),
                                label="Output resolution",
                            )
                        animation_style = gr.Dropdown(
                            choices=[
                                "Standard Studio",
                                "Cinematic Zoom",
                                "Gentle Parallax",
                                "Dynamic",
                                "Lip Sync Avatar",
                            ],
                            value="Standard Studio",
                            label="Standard motion style",
                            info="Lip Sync Avatar moves the mouth with the voiceover on CPU; no GPU or model download.",
                        )
                        with gr.Row():
                            voice_speed = gr.Slider(0.7, 1.3, value=float(settings.get("last_voice_speed", 1.0)), step=0.05, label="Voice speed")
                            motion_intensity = gr.Slider(0.1, 1.0, value=float(settings.get("last_motion_intensity", 0.5)), step=0.05, label="Motion intensity")
                        with gr.Row():
                            music_input = gr.File(file_types=["audio"], type="filepath", label="Background music (optional)")
                            music_volume = gr.Slider(0.0, 0.5, value=float(settings.get("last_music_volume", 0.15)), step=0.01, label="Music volume")
                        subtitles_enabled = gr.Checkbox(value=True, label="Burn subtitles into video")
                        gr.HTML(step_header("4", "Generate", "Voice model downloads automatically on first use (~60–80 MB)"))
                        generate_btn = gr.Button(
                            "🚀 Generate HD Video",
                            variant="primary",
                            size="lg",
                            elem_classes=["generate-btn"],
                        )

                    with gr.Column(scale=1):
                        gr.HTML(step_header("▶", "Preview & Downloads", "Your video renders here — MP4, subtitles and the full project"))
                        result_status = gr.Markdown(status("Ready", "Fill in the form and click Generate HD Video.", "info"), elem_classes=["statusbox"])
                        preview_video = gr.Video(label="Video preview", height=360)
                        with gr.Row():
                            download_video = gr.File(label="Download MP4", file_types=[".mp4"])
                            download_srt = gr.File(label="Download SRT subtitles", file_types=[".srt"])
                        download_project = gr.File(label="Download complete project ZIP", file_types=[".zip"])
                        gr.Markdown(
                            """
                            <div class="small-note">
                            <strong>Tip:</strong> Standard Studio works on almost every laptop. Choose <strong>Lip Sync Avatar</strong> for CPU-based mouth movement. For a custom cloned voice, open the <strong>Voice cloning</strong> accordion above. AI Pro generates full character motion with Wan2.2 inside ComfyUI, but needs an NVIDIA GPU and a one-time ~17 GB model download.
                            </div>
                            """
                        )

                create_language.change(
                    lambda lang: gr.update(choices=voice_choices(lang), value=recommended_voice(lang)),
                    [create_language],
                    [create_voice],
                )
                demo_en.click(
                    lambda: build_demo("en_US"),
                    [],
                    [images_input, script_input, create_language, create_voice],
                )
                demo_ur.click(
                    lambda: build_demo("ur_PK"),
                    [],
                    [images_input, script_input, create_language, create_voice],
                )
                generate_btn.click(
                    generate_video,
                    [
                        images_input,
                        script_input,
                        create_language,
                        create_voice,
                        voice_engine,
                        reference_audio,
                        clone_language,
                        clone_device,
                        mode,
                        resolution,
                        animation_style,
                        motion_intensity,
                        voice_speed,
                        subtitles_enabled,
                        music_input,
                        music_volume,
                        comfy_url,
                        ai_steps,
                        motion_prompt,
                        negative_prompt,
                    ],
                    [result_status, preview_video, download_video, download_srt, download_project],
                    queue=True,
                )

            with gr.TabItem("🗣️ Voice Models"):
                gr.Markdown(
                    """
                    ### Local multilingual voices

                    Voice models are based on **Piper TTS** and run fully offline on CPU after the first download.
                    Each voice is about 60–80 MB. The app downloads the selected voice automatically when you generate a video.
                    """
                )
                with gr.Row():
                    voice_language = gr.Dropdown(choices=languages, value=default_language, label="Language")
                    voice_dropdown = gr.Dropdown(
                        choices=voice_choices(default_language),
                        value=default_voice,
                        label="Voice model",
                    )
                with gr.Row():
                    install_voice_btn = gr.Button("⬇️ Download / verify selected voice", variant="primary")
                    refresh_voices_btn = gr.Button("🔄 Refresh list", variant="secondary")
                    delete_voice_btn = gr.Button("🗑️ Remove selected voice", variant="stop")
                voice_status = gr.Markdown("")
                installed_md = gr.Markdown(installed_voice_markdown())
                voice_card = gr.Markdown("")
                voice_language.change(
                    lambda lang: gr.update(choices=voice_choices(lang), value=recommended_voice(lang)),
                    [voice_language],
                    [voice_dropdown],
                )
                voice_dropdown.change(
                    lambda key: f"**Model card / license:** [{model_card_url(key)}]({model_card_url(key)})" if key else "",
                    [voice_dropdown],
                    [voice_card],
                )
                install_voice_btn.click(
                    install_voice_action,
                    [voice_language, voice_dropdown],
                    [voice_status, voice_dropdown, installed_md],
                )
                refresh_voices_btn.click(
                    lambda lang: (
                        status("Voice list refreshed", "Downloaded models are marked with ✓.", "ok"),
                        gr.update(choices=voice_choices(lang), value=recommended_voice(lang)),
                        installed_voice_markdown(),
                    ),
                    [voice_language],
                    [voice_status, voice_dropdown, installed_md],
                )
                delete_voice_btn.click(
                    delete_voice_action,
                    [voice_language, voice_dropdown],
                    [voice_status, voice_dropdown, installed_md],
                )

            with gr.TabItem("🚀 AI Pro Setup"):
                ready, note = pro_readiness()
                gr.Markdown(
                    f"""
                    ### Wan2.2 AI Pro setup

                    {('✅' if ready else '⚠️')} {html.escape(note)}

                    AI Pro uses ComfyUI's official Wan2.2 TI2V-5B image-to-video workflow. The model is Apache-2.0 licensed
                    and supports commercial use. Native AI clips are approximately 720p and are upscaled to your chosen
                    output resolution. Long videos are generated as multiple scenes, one per character image.

                    **One-time requirements:** ComfyUI installed, NVIDIA GPU with 8 GB+ VRAM, ~20 GB free disk space,
                    and a ~17 GB model download. No API key or cloud subscription is used.
                    """
                )
                with gr.Row():
                    test_comfy_btn = gr.Button("🔌 Test ComfyUI connection", variant="secondary")
                    check_models_btn = gr.Button("📦 Check model files", variant="secondary")
                    install_pro_btn = gr.Button("⬇️ Download Wan2.2 Pro models", variant="primary")
                pro_status = gr.Markdown("")
                pro_model_status = gr.Markdown(pro_models_markdown(settings.get("comfy_path", "")))
                gr.Markdown(
                    """
                    **Workflow:** Start ComfyUI on your laptop, then return here. The app talks to ComfyUI through its local
                    HTTP API (`/upload/image`, `/prompt`, `/history`, `/view`). Your images and prompts stay on your machine.
                    """
                )
                test_comfy_btn.click(comfy_status_markdown, [comfy_url], [pro_status])
                check_models_btn.click(pro_models_markdown, [comfy_path], [pro_model_status])
                install_pro_btn.click(install_pro_action, [comfy_path], [pro_status])

            with gr.TabItem("💻 System & Help"):
                system_md = gr.Markdown(system_markdown())
                refresh_system_btn = gr.Button("🔄 Refresh system report", variant="secondary")
                refresh_system_btn.click(lambda: system_markdown(), [], [system_md])
                gr.Markdown(
                    """
                    ### Free lifetime — what it means

                    - The app code, local TTS engine, FFmpeg export and optional Wan2.2 models have **no subscription**.
                    - First-use downloads require internet. After that, voice and video generation can run offline.
                    - You pay only for your own hardware/electricity and disk storage.
                    - Some Piper voice models have individual dataset licenses. Always check the linked model card before commercial distribution.
                    - See `THIRD_PARTY_NOTICES.md` and each upstream project's license for details.
                    """
                )

        gr.HTML(FOOTER_HTML)

    demo.queue(max_size=8, default_concurrency_limit=2)
    return demo


def main() -> None:
    parser = argparse.ArgumentParser(description="CineGen Studio — free local AI video generator")
    parser.add_argument("--host", default="127.0.0.1", help="Bind address (use 0.0.0.0 for LAN/preview access)")
    parser.add_argument("--port", type=int, default=7860, help="Web UI port")
    parser.add_argument("--share", action="store_true", help="Create a Gradio public share link (optional)")
    args = parser.parse_args()
    demo = build_ui()
    demo.launch(
        server_name=args.host,
        server_port=args.port,
        share=args.share,
        show_error=True,
        inbrowser=False,
        max_threads=4,
    )


if __name__ == "__main__":
    main()
