@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo CineGen Studio is not set up yet.
    echo Please run setup_windows.bat first.
    pause
    exit /b 1
)
echo Starting CineGen Studio...
echo Open the local address shown below in your browser.
".venv\Scripts\python.exe" app.py %*
pause
